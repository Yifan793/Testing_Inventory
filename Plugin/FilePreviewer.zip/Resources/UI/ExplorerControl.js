var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var FilePreviewer;
(function (FilePreviewer) {
    var _a;
    FilePreviewer.CardIcons = {
        "^(docx?)$": "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\"><svg t=\"1535352181201\" class=\"icon\" style=\"\" viewBox=\"0 0 1024 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"1038\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"200\" height=\"200\"><defs><style type=\"text/css\"></style></defs><path d=\"M745 186V3H93v1021h836V186z\" fill=\"#6CA2FF\" p-id=\"1039\"></path><path d=\"M929 186H745V3\" fill=\"#A2CBFC\" p-id=\"1040\"></path><path d=\"M490.4 344.2H542l65.2 227.3L651 344.2h66.1L638.5 685H578l-60.5-238.1L454.3 685h-60.5l-78.5-340.8h66.1l43.8 227.3 65.2-227.3z\" fill=\"#FCFCFC\" p-id=\"1041\"></path></svg>",
        "^(xlsx?)$": "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\"><svg t=\"1536042674582\" class=\"icon\" style=\"\" viewBox=\"0 0 1024 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"1221\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"200\" height=\"200\"><defs><style type=\"text/css\"></style></defs><path d=\"M745 184.3V1H93v1022.5h836V184.3z\" fill=\"#72DCA2\" p-id=\"1222\"></path><path d=\"M928.8 184h-184V0.8\" fill=\"#A9FFCE\" p-id=\"1223\"></path><path d=\"M500.8 476.2l76.6-131h67.7L532.5 537.9 445.7 686H378l122.8-209.8z m-0.7 70.3l-6.6-11-112.7-190.3h67.7L525 474.4l8.9 15.2L650.3 686h-67.7l-82.5-139.5z\" fill=\"#FCFCFC\" p-id=\"1224\"></path></svg>",
        "^(pptx?)$": "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\"><svg t=\"1536042669657\" class=\"icon\" style=\"\" viewBox=\"0 0 1024 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"1082\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"200\" height=\"200\"><defs><style type=\"text/css\"></style></defs><path d=\"M745 186V3H93v1021h836V186z\" fill=\"#FF8278\" p-id=\"1083\"></path><path d=\"M929 186H745V2.7\" fill=\"#FFB7B3\" p-id=\"1084\"></path><path d=\"M390.5 341.2h64.2V682h-64.2V341.2z m29.3 146.7h109c7.7 0 14.4-1.8 20.3-5.3s10.4-8.5 13.7-14.9 4.9-13.7 4.9-22c0-8.4-1.6-15.9-4.8-22.4s-7.7-11.5-13.6-15-12.7-5.3-20.5-5.3h-109v-61.9h107.3c21.2 0 40 4.3 56.1 13s28.7 20.9 37.6 36.7c8.9 15.8 13.4 34.1 13.4 54.8 0 20.8-4.5 39-13.4 54.7s-21.4 27.9-37.6 36.4c-16.2 8.6-34.9 12.9-56.1 12.9H419.8v-61.7z\" fill=\"#FFFFFF\" p-id=\"1085\"></path></svg>",
        "^(wav|mp3)$": "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\"><svg t=\"1536042657816\" class=\"icon\" style=\"\" viewBox=\"0 0 1024 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"804\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"200\" height=\"200\"><defs><style type=\"text/css\"></style></defs><path d=\"M748 183.5V0H96v1024h836V183.5z\" fill=\"#FF6955\" p-id=\"805\"></path><path d=\"M932 184H748V0\" fill=\"#FFA694\" p-id=\"806\"></path><path d=\"M586.7 302.1c-5.3 7.5-34.2 20.3-58.7 25.6-31 6.4-47 11.7-63 20.3-21.3 12.8-33.1 28.8-31 43.8 1.1 3.2 26.7 40.6 56.6 83.2 31 42.7 56.6 79 57.6 80 1.1 2.1-3.2 2.1-18.1 1.1-47-3.2-89.6 21.3-108.9 59.8-5.3 11.7-6.4 18.1-6.4 32 0 32 17.1 57.6 49.1 72.6 12.8 5.3 17.1 6.4 43.8 6.4 28.8 0 29.9 0 49.1-9.6C608 692.8 629.4 644.7 608 601c-4.3-9.6-31-55.5-59.8-102.5L496 412h8.5c34.2-2.1 57.6-12.8 73.6-31 13.9-16 18.1-32 17.1-57.6-1-23.5-3.2-28.8-8.5-21.3z\" fill=\"#FFFFFF\" p-id=\"807\"></path></svg>",
        "^(mp4|webm|ogg|avi|swf)$": "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\"><svg t=\"1536042662037\" class=\"icon\" style=\"\" viewBox=\"0 0 1024 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"943\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"200\" height=\"200\"><defs><style type=\"text/css\"></style></defs><path d=\"M748 183.5V0H96v1024h836V183.5z\" fill=\"#E657FF\" p-id=\"944\"></path><path d=\"M932 184H748V0\" fill=\"#F797FF\" p-id=\"945\"></path><path d=\"M635.3 459.6l52.3-30.3c9.2-5.5 17.4-0.9 17.4 8.3v151.3c0 11-7.3 14.7-17.4 8.3l-52.3-30.3c-9.2-5.5-17.4-11.9-17.4-21.1v-66.9c0-8.3 8.3-13.8 17.4-19.3z m-82.5-56.8H356.7c-20.2 0-36.7 16.5-36.7 36.7v157.7c0 20.2 16.5 36.7 36.7 36.7h196.2c20.2 0 36.7-16.5 36.7-36.7V439.5c-0.1-20.2-16.6-36.7-36.8-36.7z m-118.2 88.9c-2.8 13.8-13.8 23.8-25.7 26.6-23.8 4.6-44-16.5-39.4-39.4 2.8-13.8 13.8-23.8 25.7-25.7 23.8-6.4 44 13.8 39.4 38.5z\" fill=\"#FFFFFF\" p-id=\"946\"></path></svg>",
        "^(pdf)$": "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\"><svg t=\"1535353718411\" class=\"icon\" style=\"\" viewBox=\"0 0 1024 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"1164\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"200\" height=\"200\"><defs><style type=\"text/css\"></style></defs><path d=\"M748 183.5V0H96v1024h836V183.5z\" fill=\"#FF5562\" p-id=\"1165\"></path><path d=\"M932 184H748V0\" fill=\"#FF9292\" p-id=\"1166\"></path><path d=\"M657.9 606.1c-29.4-1.9-57.4-12.9-79.9-31.3-44.2 9.4-86.3 22.9-128.4 39.6-33.5 57.4-64.8 86.6-91.8 86.6-5.4 0-11.9-1-16.2-4.2-11.3-5.1-18.5-16.1-18.3-28.2 0-9.4 2.1-35.5 104.7-78.2 23.3-41.3 42.4-84.6 57.2-129.4-12.9-25-41-86.6-21.6-117.9 6.5-11.5 19.4-17.7 33.5-16.7 11 0.1 21.4 5.1 28.1 13.6 14 18.8 12.9 58.4-5.4 116.8 17.3 31.3 39.9 59.5 66.9 83.5 22.7-4.2 45.3-7.3 68-7.3 50.7 1 58.3 24 57.2 37.5 0 35.6-35.7 35.6-54 35.6z m-302.2 64.6l3.2-1c15.1-5.2 27-15.6 35.6-29.2-16.2 6.3-29.1 16.6-38.8 30.2z m143.5-312.9H496c-1.1 0-3.3 0-4.3 1-4.3 17.7-1.1 36.5 6.5 53.2 6.2-17.5 6.6-36.5 1-54.2z m7.6 151.2l-1.1 2.1-1.1-1.1c-9.7 24-20.5 48-32.4 70.9l2.1-1v2.1c24-8.4 48.5-15.3 73.4-20.9l-1-1h3.3c-16.2-15.5-30.7-32.6-43.2-51.1z m146.8 55.3c-9.7 0-18.3 0-28 2.1 10.8 5.2 21.6 7.3 32.4 8.3 7.6 1 15.1 0 21.6-2.1-0.1-3-4.4-8.3-26-8.3z\" fill=\"#FFFFFF\" p-id=\"1167\"></path></svg>",
        "^(zip|rar|tar|7z)$": "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\"><svg t=\"1535356709153\" class=\"icon\" style=\"\" viewBox=\"0 0 1024 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"4087\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"200\" height=\"200\"><defs><style type=\"text/css\"></style></defs><path d=\"M748 183.5V0H96v1024h836V183.5z\" fill=\"#DBB375\" p-id=\"4088\"></path><path d=\"M932 184H748V0\" fill=\"#FFD597\" p-id=\"4089\"></path><path d=\"M223 0h96v96h-96zM319 96h96v96h-96zM223 192h96v96h-96zM319 288h96v96h-96zM223 384h96v96h-96zM319 480h96v96h-96z\" fill=\"#FFFFFF\" p-id=\"4090\"></path></svg>",
        "unknown": "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\"><svg t=\"1535354583021\" class=\"icon\" style=\"\" viewBox=\"0 0 1024 1024\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" p-id=\"1286\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"200\" height=\"200\"><defs><style type=\"text/css\"></style></defs><path d=\"M740 185V2H88v1021h836V185z\" fill=\"#F0F0F0\" p-id=\"1287\"></path><path d=\"M923 185H739V1\" fill=\"#DDDDDD\" p-id=\"1288\"></path></svg>",
    };
    var LayoutCssNames = (_a = {},
        _a[0 /* LayoutMode.Medium */] = "FP-layout-medium",
        _a[1 /* LayoutMode.ExtraLarge */] = "FP-layout-extralarge",
        _a[2 /* LayoutMode.Large */] = "FP-layout-large",
        _a[3 /* LayoutMode.Small */] = "FP-layout-small",
        _a[4 /* LayoutMode.List */] = "FP-layout-list",
        _a[5 /* LayoutMode.Custom */] = "FP-layout-custom",
        _a);
    var ExplorerControl = /** @class */ (function (_super) {
        __extends(ExplorerControl, _super);
        function ExplorerControl() {
            var _this = _super.call(this) || this;
            _this.fileItems = [];
            _this.selectedItems = [];
            _this.readonly = false;
            _this.isHiddenFileName = false;
            _this.isHiddenToolbar = false;
            _this.isSmallButtonMode = false;
            _this.layoutMode = 0 /* LayoutMode.Medium */;
            _this.customWidth = 64;
            _this.customHeight = 64;
            _this.maxFileCount = Number.MAX_VALUE;
            _this.registProperty("readonly");
            _this.registProperty("isHiddenFileName");
            _this.registProperty("isHiddenToolbar");
            _this.registProperty("isSmallButtonMode");
            _this.registProperty("layoutMode");
            return _this;
        }
        Object.defineProperty(ExplorerControl.prototype, "allowAddFile", {
            get: function () {
                return this.enabled && !this.readonly && this.fileItems.length < this.maxFileCount;
            },
            enumerable: false,
            configurable: true
        });
        ExplorerControl.prototype.addFile = function () {
            var _a;
            var fileItems = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                fileItems[_i] = arguments[_i];
            }
            if (fileItems) {
                (_a = this.fileItems).push.apply(_a, fileItems.filter(function (v) { return v !== null && v !== undefined; }));
                this.dispatch("FileItemsChanged" /* ExplorerControlEvents.FileItemsChanged */, __spreadArray([], this.fileItems, true));
            }
        };
        ExplorerControl.prototype.removeFile = function (fileItem) {
            if (fileItem) {
                var index = this.fileItems.indexOf(fileItem);
                if (index >= 0) {
                    this.fileItems.splice(index, 1);
                    this.removeSelect(fileItem);
                    this.dispatch("FileItemsChanged" /* ExplorerControlEvents.FileItemsChanged */, __spreadArray([], this.fileItems, true));
                }
            }
        };
        ExplorerControl.prototype.replaceFile = function (fileItem, repalceItem) {
            if (fileItem && repalceItem) {
                var index = this.fileItems.indexOf(fileItem);
                if (index >= 0) {
                    this.fileItems.splice(index, 1, repalceItem);
                    this.removeSelect(fileItem);
                    this.dispatch("FileItemsChanged" /* ExplorerControlEvents.FileItemsChanged */, __spreadArray([], this.fileItems, true));
                }
            }
        };
        ExplorerControl.prototype.clearFiles = function (onlyNormalFiles) {
            if (onlyNormalFiles === void 0) { onlyNormalFiles = true; }
            if (onlyNormalFiles) {
                this.fileItems = this.fileItems.filter(function (i) { return i.status === 1 /* FileStatus.Loading */; });
                this.selectedItems = this.selectedItems.filter(function (i) { return i.status === 1 /* FileStatus.Loading */; });
                this.dispatch("SelectedItemsChanged" /* ExplorerControlEvents.SelectedItemsChanged */, __spreadArray([], this.selectedItems, true));
                this.dispatch("FileItemsChanged" /* ExplorerControlEvents.FileItemsChanged */, __spreadArray([], this.fileItems, true));
            }
            else {
                this.fileItems = [];
                this.selectedItems = [];
                this.dispatch("SelectedItemsChanged" /* ExplorerControlEvents.SelectedItemsChanged */, __spreadArray([], this.selectedItems, true));
                this.dispatch("FileItemsChanged" /* ExplorerControlEvents.FileItemsChanged */, __spreadArray([], this.fileItems, true));
            }
        };
        ExplorerControl.prototype.select = function (fileItem) {
            if (fileItem) {
                this.selectedItems = [];
                this.selectedItems.push(fileItem);
                this.dispatch("SelectedItemsChanged" /* ExplorerControlEvents.SelectedItemsChanged */, __spreadArray([], this.selectedItems, true));
            }
        };
        ExplorerControl.prototype.selectAll = function () {
            var _a;
            if (this.fileItems.length > 0) {
                this.selectedItems = [];
                (_a = this.selectedItems).push.apply(_a, this.fileItems);
                this.dispatch("SelectedItemsChanged" /* ExplorerControlEvents.SelectedItemsChanged */, __spreadArray([], this.selectedItems, true));
            }
        };
        ExplorerControl.prototype.ctrlSelect = function (fileItem) {
            if (fileItem) {
                var index = this.selectedItems.indexOf(fileItem);
                if (index < 0) {
                    this.selectedItems.push(fileItem);
                }
                else {
                    this.selectedItems.splice(index, 1);
                }
                this.dispatch("SelectedItemsChanged" /* ExplorerControlEvents.SelectedItemsChanged */, __spreadArray([], this.selectedItems, true));
            }
        };
        ExplorerControl.prototype.removeSelect = function (fileItem) {
            if (fileItem) {
                var index = this.selectedItems.indexOf(fileItem);
                if (index >= 0) {
                    this.selectedItems.splice(index, 1);
                    this.dispatch("SelectedItemsChanged" /* ExplorerControlEvents.SelectedItemsChanged */, __spreadArray([], this.selectedItems, true));
                }
            }
        };
        ExplorerControl.prototype.clearSelect = function () {
            if (this.selectedItems.length > 0) {
                this.selectedItems = [];
                this.dispatch("SelectedItemsChanged" /* ExplorerControlEvents.SelectedItemsChanged */, []);
            }
        };
        return ExplorerControl;
    }(FilePreviewer.UserControl));
    FilePreviewer.ExplorerControl = ExplorerControl;
    /**
     * 文件浏览器视图
     */
    var ExplorerView = /** @class */ (function (_super) {
        __extends(ExplorerView, _super);
        function ExplorerView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ExplorerView.prototype.createContainer = function () {
            this.container = $("<div class=\"FP-explorer\"></div>");
        };
        ExplorerView.prototype.createChildren = function () {
            if (!this.target.isHiddenToolbar) {
                this.addChild(new ToolbarView(this.target));
            }
            this.addChild(new ContentView(this.target));
        };
        return ExplorerView;
    }(FilePreviewer.ControlUIBase));
    FilePreviewer.ExplorerView = ExplorerView;
    var ToolbarButtons = /** @class */ (function () {
        function ToolbarButtons() {
        }
        return ToolbarButtons;
    }());
    var ToolbarView = /** @class */ (function (_super) {
        __extends(ToolbarView, _super);
        function ToolbarView() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        Object.defineProperty(ToolbarView.prototype, "readonly", {
            set: function (value) {
                if (value) {
                    this.buttons.upload.setAttribute("disabled", "");
                    this.buttons.delete.setAttribute("disabled", "");
                }
                else {
                    if (this.target.enabled) {
                        this.buttons.upload.removeAttribute("disabled");
                        if (this.target.selectedItems.length > 0) {
                            this.buttons.delete.removeAttribute("disabled");
                        }
                    }
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ToolbarView.prototype, "isSmallButtonMode", {
            set: function (value) {
                if (value) {
                    this.container.find("button").addClass("btn-sm");
                }
                else {
                    this.container.find("button").removeClass("btn-sm");
                }
            },
            enumerable: false,
            configurable: true
        });
        ToolbarView.prototype.dispose = function () {
            this.target.off("SelectedItemsChanged" /* ExplorerControlEvents.SelectedItemsChanged */, this.selectedItemsChangedHandler);
            _super.prototype.dispose.call(this);
        };
        ToolbarView.prototype.createContainer = function () {
            this.container = $("<div class=\"FP-explorer-toolbar\"></div>");
        };
        ToolbarView.prototype.createContainerEvents = function () {
            var _this = this;
            _super.prototype.createContainerEvents.call(this);
            this.selectedItemsChangedHandler = function () {
                _this.initButtonsAttribute(_this.buttons);
            };
            this.target.on("SelectedItemsChanged" /* ExplorerControlEvents.SelectedItemsChanged */, this.selectedItemsChangedHandler);
            this.target.on("PropertyChanged" /* UserControlEvents.PropertyChanged */, function (propertyName) {
                if (propertyName === "enabled" || propertyName === "readonly") {
                    _this.initButtonsAttribute(_this.buttons);
                }
            });
        };
        ToolbarView.prototype.createChildren = function () {
            var _this = this;
            var small = this.target.isSmallButtonMode ? "btn-sm" : "";
            var toolbar = $("<div class=\"btn-toolbar\" role=\"toolbar\">\n  <div class=\"btn-group mr-2\" role=\"group\">\n    <button type=\"button\" class=\"btn btn-primary ".concat(small, "\">").concat(FilePreviewer.Resources.Button_Upload, "</button>\n  </div>\n  <div class=\"btn-group mr-2\" role=\"group\">\n    <button type=\"button\" class=\"btn btn-secondary ").concat(small, "\">").concat(FilePreviewer.Resources.Button_Preview, "</button>\n    <button type=\"button\" class=\"btn btn-secondary ").concat(small, "\">").concat(FilePreviewer.Resources.Button_Download, "</button>\n    <button type=\"button\" class=\"btn btn-secondary ").concat(small, "\">").concat(FilePreviewer.Resources.Button_Delete, "</button>\n  </div>\n</div>"));
            var events = [
                "Upload" /* ExplorerControlEvents.Upload */,
                "Preview" /* ExplorerControlEvents.Preview */,
                "Download" /* ExplorerControlEvents.Download */,
                "Delete" /* ExplorerControlEvents.Delete */
            ];
            var buttons = new ToolbarButtons();
            var jqueryButtons = toolbar.find("button");
            jqueryButtons.map(function (index, button) {
                buttons[events[index].toLowerCase()] = button;
                button.addEventListener("click", function () {
                    _this.target.dispatch(events[index], __spreadArray([], _this.target.selectedItems, true));
                });
            });
            this.initButtonsAttribute(buttons);
            this.buttons = buttons;
            this.container.append(toolbar);
        };
        ToolbarView.prototype.initButtonsAttribute = function (buttons) {
            if (!this.target) {
                return;
            }
            //disable 
            buttons.upload.setAttribute("disabled", "");
            buttons.preview.setAttribute("disabled", "");
            buttons.download.setAttribute("disabled", "");
            buttons.delete.setAttribute("disabled", "");
            //enable
            if (this.target.enabled) {
                //readonly
                if (this.target.readonly) {
                    //can't upload and delete
                    if (this.target.selectedItems.length > 0) {
                        //can preview and download
                        buttons.preview.removeAttribute("disabled");
                        buttons.download.removeAttribute("disabled");
                    }
                }
                else {
                    //can edit
                    buttons.upload.removeAttribute("disabled");
                    if (this.target.selectedItems.length > 0) {
                        buttons.preview.removeAttribute("disabled");
                        buttons.download.removeAttribute("disabled");
                        buttons.delete.removeAttribute("disabled");
                    }
                }
            }
        };
        return ToolbarView;
    }(FilePreviewer.ControlUIBase));
    var ContentView = /** @class */ (function (_super) {
        __extends(ContentView, _super);
        function ContentView() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.cards = [];
            return _this;
        }
        Object.defineProperty(ContentView.prototype, "focusable", {
            set: function (value) {
                return;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ContentView.prototype, "isFocus", {
            set: function (value) {
                return;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ContentView.prototype, "readonly", {
            set: function (value) {
                this.container.toggleClass("FP-readonly" /* GeneralCssNames.Readonly */, value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ContentView.prototype, "isHiddenFileName", {
            set: function (value) {
                this.container.toggleClass("FP-explorer-hiddenfilename", value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ContentView.prototype, "isHiddenToolbar", {
            set: function (value) {
                this.container.toggleClass("FP-explorer-hiddentoolbar", value);
            },
            enumerable: false,
            configurable: true
        });
        ContentView.prototype.dispose = function () {
            this.pasteHandler && $(document).off("paste", this.pasteHandler);
            this.target.off("SelectedItemsChanged" /* ExplorerControlEvents.SelectedItemsChanged */, this.selectedItemsChangedHandler);
            this.target.off("FileItemsChanged" /* ExplorerControlEvents.FileItemsChanged */, this.fileItemsChangedHandler);
            _super.prototype.dispose.call(this);
        };
        ContentView.prototype.createContainer = function () {
            this.container = $("<div class=\"FP-explorer-content\" tabindex=\"0\"></div>");
            this.attachLayoutClassNames();
        };
        ContentView.prototype.createContainerEvents = function () {
            var _this = this;
            _super.prototype.createContainerEvents.call(this);
            this.container.on("keydown", function (e) {
                if (e.ctrlKey && e.keyCode === 65) {
                    e.preventDefault();
                    e.stopPropagation();
                    _this.target.selectAll();
                }
            });
            this.selectedItemsChangedHandler = function () {
                _this.refreshCardsSelectedStatus(_this.cards);
            };
            this.target.on("SelectedItemsChanged" /* ExplorerControlEvents.SelectedItemsChanged */, this.selectedItemsChangedHandler);
            this.fileItemsChangedHandler = function () {
                _this.refreshCards();
            };
            this.target.on("FileItemsChanged" /* ExplorerControlEvents.FileItemsChanged */, this.fileItemsChangedHandler);
            this.addFilesByDragDrop();
            this.addFilesByClipboard();
        };
        ContentView.prototype.createChildren = function () {
            this.refreshCards();
        };
        ContentView.prototype.attachLayoutClassNames = function () {
            this.container.addClass(LayoutCssNames[this.target.layoutMode]);
            if (this.target.layoutMode === 5 /* LayoutMode.Custom */) {
                var guid = FilePreviewer.GUID.generate();
                this.container.attr("style-id", guid);
                $("body").append($("<style>.FP-layout-custom[style-id=\"".concat(guid, "\"] > .FP-file{width:").concat(this.target.customWidth, "px; height:").concat(this.target.customHeight, "px}</style>")));
            }
        };
        ContentView.prototype.refreshCards = function () {
            var _a;
            var _this = this;
            var cards = this.target.fileItems.map(function (v) {
                var card = IconCardBuilder.create(v);
                card.data("fileItem", v);
                card.click(function (event) {
                    _this.target.activeItem = v;
                    if (event.ctrlKey) {
                        _this.target.ctrlSelect(v);
                    }
                    else {
                        _this.target.select(v);
                    }
                    _this.refreshCardsActiveStatus(cards, card);
                });
                card.find(".FP-file-icon").click(function (e) {
                    if (_this.target.enabled && _this.target.clickToPreview) {
                        _this.target.dispatch("Preview" /* ExplorerControlEvents.Preview */, [v]);
                    }
                });
                card.find(".FP-file-icon").dblclick(function (e) {
                    if (_this.target.enabled && !_this.target.clickToPreview) {
                        _this.target.dispatch("Preview" /* ExplorerControlEvents.Preview */, [v]);
                    }
                });
                card.find(".FP-file-text").click(function () {
                    if (_this.target.enabled) {
                        if (_this.target.clickFileNameToPreview) {
                            _this.target.dispatch("Preview" /* ExplorerControlEvents.Preview */, [v]);
                        }
                        else {
                            _this.target.dispatch("Download" /* ExplorerControlEvents.Download */, [v]);
                        }
                    }
                });
                card.find(".FP-file-delete").click(function () {
                    if (_this.target.enabled && !_this.target.readonly) {
                        _this.target.dispatch("Delete" /* ExplorerControlEvents.Delete */, [v]);
                    }
                });
                return card;
            });
            this.cards = cards;
            this.refreshCardsSelectedStatus(cards);
            this.container.empty();
            (_a = this.container).append.apply(_a, cards);
            this.addCreateNewFileCard();
        };
        ContentView.prototype.refreshCardsSelectedStatus = function (cards) {
            var _this = this;
            cards.forEach(function (c) {
                var isSelected = _this.target.selectedItems.indexOf(c.data("fileItem")) >= 0;
                c.toggleClass("FP-selected" /* GeneralCssNames.Selected */, isSelected);
            });
        };
        ContentView.prototype.refreshCardsActiveStatus = function (cards, activeItem) {
            cards.forEach(function (c) {
                var isActived = activeItem === c;
                c.toggleClass("FP-actived" /* GeneralCssNames.Actived */, isActived);
            });
        };
        ContentView.prototype.addCreateNewFileCard = function () {
            var _this = this;
            if (this.target.isHiddenToolbar && this.target.fileItems.length < this.target.maxFileCount) {
                var card = IconCardBuilder.createNewCard(this.target.customUploadIcon);
                card.click(function () {
                    _this.target.dispatch("Upload" /* ExplorerControlEvents.Upload */);
                });
                this.container.append(card);
            }
        };
        ContentView.prototype.addFilesByDragDrop = function () {
            var _this = this;
            this.container.on("dragenter", function (e) {
                e.preventDefault();
                e.stopPropagation();
            });
            this.container.on("dragleave", function (e) {
                e.preventDefault();
                e.stopPropagation();
            });
            this.container.on("dragover", function (e) {
                e.preventDefault();
                e.stopPropagation();
            });
            this.container.on("drop", function (e) {
                e.preventDefault();
                e.stopPropagation();
                if (_this.target.allowAddFile) {
                    var files = _this.getFilesFromDataTransfer(e.originalEvent.dataTransfer);
                    _this.target.dispatch("DropFile" /* ExplorerControlEvents.DropFile */, files);
                }
            });
        };
        ContentView.prototype.addFilesByClipboard = function () {
            var _this = this;
            this.pasteHandler && $(document).off("paste", this.pasteHandler);
            this.pasteHandler = function (e) {
                if (_this.target.allowAddFile && _this.container.is(":focus")) {
                    var files = _this.getFilesFromDataTransfer(e.originalEvent.clipboardData);
                    _this.target.dispatch("PasterFile" /* ExplorerControlEvents.PasteFile */, files);
                }
            };
            $(document).on("paste", this.pasteHandler);
        };
        ContentView.prototype.getFilesFromDataTransfer = function (dataTransfer) {
            var files = [];
            if (dataTransfer) {
                var fileList = dataTransfer.files;
                if (fileList && fileList.length > 0) {
                    for (var i = 0; i < fileList.length; i++) {
                        files.push(fileList[i]);
                    }
                }
            }
            return files;
        };
        return ContentView;
    }(FilePreviewer.ControlUIBase));
    /**
     * 文件缩略图卡片构建器
     */
    var IconCardBuilder = /** @class */ (function () {
        function IconCardBuilder() {
        }
        IconCardBuilder.create = function (fileItem) {
            if (fileItem) {
                if (fileItem.status === 0 /* FileStatus.Normal */) {
                    var type = fileItem.getFileType();
                    if (type === 1 /* FileType.Image */) {
                        return this.createImageCard(fileItem);
                    }
                    else {
                        return this.createTextCard(fileItem);
                    }
                }
                else {
                    return this.createLoadingCard(fileItem);
                }
            }
            else {
                return this.createNewCard();
            }
        };
        IconCardBuilder.createImageCard = function (fileItem) {
            var displayFileName = fileItem.getDisplayFileName();
            var card = $("\n<div class=\"FP-file\">\n  <div class=\"FP-file-delete\"></div>\n  <div class=\"FP-file-icon\">\n      <img class=\"FP-file-image\" alt=\"image\" />\n  </div>\n  <div class=\"FP-file-text\" title=\"".concat(displayFileName, "\">").concat(displayFileName, "</div>\n</div>"));
            card.find(".FP-file-image").attr("src", fileItem.getEncodeURIComponentSrc());
            card.find(".FP-file-text").text(displayFileName).attr("title", displayFileName);
            return card;
        };
        IconCardBuilder.createTextCard = function (fileItem) {
            var displayFileName = fileItem.getDisplayFileName();
            var extension = fileItem.getExtension();
            var card = $("\n<div class=\"FP-file\">\n  <div class=\"FP-file-delete\"></div>\n  <div class=\"FP-file-icon\">".concat(IconProvider.get(extension), "</div>\n  <div class=\"FP-file-text\"></div>\n</div>"));
            card.find(".FP-file-text").text(displayFileName).attr("title", displayFileName);
            return card;
        };
        IconCardBuilder.createLoadingCard = function (fileItem) {
            var displayFileName = fileItem.getDisplayFileName();
            var extension = fileItem.getExtension();
            var card = $("\n<div class=\"FP-file\">\n  <div class=\"FP-file-icon\">\n    ".concat(IconProvider.get(extension), "\n  </div>\n  <div class=\"FP-file-text\"></div>\n    <div class=\"FP-file-loading\">\n        <span>0%</span>\n    </div>\n</div>"));
            card.find(".FP-file-text").text(displayFileName).attr("title", displayFileName);
            fileItem.events.addHandler("ProgressChanged" /* LoadingFileItemEvents.ProgressChanged */, function (e) {
                card.find(".FP-file-loading>span").text(Math.floor(e.loaded / e.total * 99).toString() + "%");
            });
            return card;
        };
        IconCardBuilder.createNewCard = function (icon) {
            if (icon) {
                var src = void 0;
                if (icon.BuiltIn) {
                    src = Forguncy.Helper.SpecialPath.getBuiltInImageFolderPath() + icon.Name;
                }
                else {
                    src = Forguncy.Helper.SpecialPath.getImageEditorUploadImageFolderPath() + encodeURIComponent(icon.Name);
                }
                if (Forguncy.ImageDataHelper.IsSvg(src)) {
                    var svgHtml_1 = "";
                    $.ajax({
                        url: src,
                        success: function (data) {
                            var svg = $(data.documentElement);
                            svg.addClass("icon");
                            Forguncy.ImageHelper.preHandleSvg(svg, icon.UseCellTypeForeColor ? "currentColor" : icon.Color);
                            svgHtml_1 = svg[0].outerHTML;
                        },
                        async: false
                    });
                    return $("<div class=\"FP-file FP-file-new\">".concat(svgHtml_1, "</div>"));
                }
                else {
                    return $("<div class=\"FP-file FP-file-new\"><img class=\"icon\" src=".concat(src, "></img></div>"));
                }
            }
            return $("<div class=\"FP-file FP-file-new\"><svg class=\"icon\" viewBox=\"0 0 1024 1024\" version=\"1.1\" width=\"200\" height=\"200\"><path d=\"M741.293764 527.347516M895.794308 703.986185c-0.120755 0-3.722929-7.00554-8.003582-15.566503l-112.241509-224.461766c-4.281676-8.561986-15.616246-15.564456-25.188615-15.561386l-93.023089 0.030699c-9.57237 0.00307-17.405053 7.837487-17.405053 17.410497l0 29.574513c0 9.571987 7.83166 17.409474 17.405053 17.416637l29.574672 0.019443c9.57237 0.007163 20.878286 7.031123 25.124145 15.610505l79.554845 160.755966c4.244835 8.579382-0.112568 15.598225-9.685961 15.598225L655.550752 704.813015c-9.57237 0-17.405053 7.831347-17.405053 17.404357l0 91.05258c0 9.571987-7.83166 17.404357-17.405053 17.404357L401.767317 830.674309c-9.57237 0-17.405053-7.831347-17.405053-17.404357l0-91.05258c0-9.571987-7.83166-17.404357-17.405053-17.404357L238.042341 704.813015c-9.57237 0-13.814135-6.960515-9.425008-15.467242l83.198977-161.273758c4.389127-8.506727 15.811705-15.462126 25.384074-15.455986l28.808187 0.018419c9.57237 0.007163 17.405053-7.82009 17.405053-17.392077l0-29.317664c0-9.571987-7.83166-17.401287-17.405053-17.398217l-92.596354 0.030699c-9.57237 0.00307-20.921266 7.004517-25.220339 15.557293L135.393668 688.580341c-4.298049 8.552776-7.713975 15.551153-7.591174 15.551153 0.123825 0 0.224113 7.831347 0.224113 17.404357l0 158.054443c0 9.571987 7.83166 17.404357 17.405053 17.404357l733.178638 0c9.57237 0 17.405053-7.831347 17.405053-17.404357L896.01535 721.389519C896.014327 711.817532 895.916086 703.986185 895.794308 703.986185zM352.516789 371.13195l95.516981 0 0 268.105688 127.918132 0 0-268.105688 100.632683 0c9.57237 0 12.210553-5.861486 5.86172-13.025639L523.92811 179.239909c-6.348833-7.164152-16.668244-7.102754-22.930093 0.137123L346.498497 357.969189C340.235625 365.209066 342.943396 371.13195 352.516789 371.13195z\" fill=\"#cccccc\"></path></svg></div>");
        };
        return IconCardBuilder;
    }());
    var IconProvider = /** @class */ (function () {
        function IconProvider() {
        }
        IconProvider.get = function (extension) {
            for (var key in FilePreviewer.CardIcons) {
                if (new RegExp(key).test(extension)) {
                    return FilePreviewer.CardIcons[key];
                }
            }
            return FilePreviewer.CardIcons["unknown"];
        };
        return IconProvider;
    }());
})(FilePreviewer || (FilePreviewer = {}));
//# sourceMappingURL=ExplorerControl.js.map