var FilePreviewer;
(function (FilePreviewer) {
    var Resources = /** @class */ (function () {
        function Resources() {
        }
        return Resources;
    }());
    FilePreviewer.Resources = Resources;
    var resource = Forguncy.Plugin.LocalizationResourceHelper.getPluginResource("11412201-dab2-422f-9281-5ccbe1c5d172");
    for (var key in resource) {
        Resources[key] = resource[key];
    }
})(FilePreviewer || (FilePreviewer = {}));
