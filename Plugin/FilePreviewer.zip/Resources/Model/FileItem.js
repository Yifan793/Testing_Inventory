var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var FilePreviewer;
(function (FilePreviewer) {
    /**
     * 文件项
     */
    var FileItem = /** @class */ (function () {
        function FileItem(src) {
            this.status = 0 /* FileStatus.Normal */;
            this.src = src;
        }
        /**
         * 返回编码路径，仅编码文件名
         */
        FileItem.prototype.getEncodeURIComponentSrc = function () {
            return encodeURIComponent(this.src);
        };
        /**
        * 返回编码路径，编码全部路径
        */
        FileItem.prototype.getEntireEncodeURIComponentSrc = function () {
            return encodeURIComponent(this.getEncodeURIComponentSrc());
        };
        FileItem.prototype.getKKFileAccessUrl = function () {
            return this.getEncodeURIComponentSrc();
        };
        /**
         * 返回存储路径
         */
        FileItem.prototype.getStorageSrc = function () {
            return this.src;
        };
        /**
         * 返回文件扩展名
         */
        FileItem.prototype.getExtension = function () {
            return this.src.toLowerCase().split('.').splice(-1)[0];
        };
        /**
         * 返回文件名
         */
        FileItem.prototype.getFileName = function () {
            return this.src.split('/').splice(-1)[0];
        };
        /**
         * 返回用于显示的文件名
         */
        FileItem.prototype.getDisplayFileName = function () {
            return this.getFileName();
        };
        /**
         * 返回文件类型
         */
        FileItem.prototype.getFileType = function () {
            var extension = this.getExtension();
            if (/(jpg|jpeg|gif|bmp|png)/.test(extension)) {
                return 1 /* FileType.Image */;
            }
            else if (/(doc|docx|xls|xlsx|ppt|pptx)/.test(extension)) {
                return 2 /* FileType.Office */;
            }
            else if (/(pdf)/.test(extension)) {
                return 3 /* FileType.Pdf */;
            }
            else if (/(wav|mp3|mp4|webm|ogg|avi|swf)/.test(extension)) {
                return 4 /* FileType.Media */;
            }
            else {
                return 0 /* FileType.Unkown */;
            }
        };
        return FileItem;
    }());
    FilePreviewer.FileItem = FileItem;
    var LoadingFileItem = /** @class */ (function (_super) {
        __extends(LoadingFileItem, _super);
        function LoadingFileItem() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.status = 1 /* FileStatus.Loading */;
            _this.events = new FilePreviewer.Events();
            return _this;
        }
        LoadingFileItem.prototype.change = function (e) {
            this.events.raiseEvent("ProgressChanged" /* LoadingFileItemEvents.ProgressChanged */, e);
        };
        return LoadingFileItem;
    }(FileItem));
    FilePreviewer.LoadingFileItem = LoadingFileItem;
    /**
     * 文件项帮助类
     */
    var FileItemHelper = /** @class */ (function () {
        function FileItemHelper() {
        }
        FileItemHelper.parseFromString = function (value, metadata) {
            var _this = this;
            if (value) {
                var splits = value.split("|");
                var fileItems = splits.map(function (segment) {
                    //override
                    if (Forguncy.getFileItemInFilePreviewer) {
                        return Forguncy.getFileItemInFilePreviewer.call(_this, segment);
                    }
                    if (!FilePreviewer.StringHelper.isNullOrEmpty(segment)) {
                        if (/<.+>/.test(segment)) {
                            var real = segment.slice(segment.indexOf("<") + 1, segment.indexOf(">"));
                            if (real === "Tencent" /* ExternalStorageServices.Tencent */) {
                                var url = segment.slice(segment.indexOf(">") + 1);
                                return new FilePreviewer.TencentCloudFileItem(url);
                            }
                            return null;
                        }
                        else {
                            return new FilePreviewer.ServerFileItem(segment);
                        }
                    }
                });
                return fileItems;
            }
            else {
                return [];
            }
        };
        return FileItemHelper;
    }());
    FilePreviewer.FileItemHelper = FileItemHelper;
})(FilePreviewer || (FilePreviewer = {}));
