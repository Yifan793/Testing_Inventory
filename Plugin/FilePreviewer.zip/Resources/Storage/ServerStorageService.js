var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var FilePreviewer;
(function (FilePreviewer) {
    var ServeBaseUrl = /** @class */ (function () {
        function ServeBaseUrl() {
        }
        ServeBaseUrl.getUploadUrl = function () {
            return window.location.origin + Forguncy.Helper.SpecialPath.getBaseUrl() + "FileDownloadUpload/Upload";
        };
        ServeBaseUrl.getAccessUrl = function () {
            return window.location.origin + Forguncy.Helper.SpecialPath.getBaseUrl() + "Upload/";
        };
        return ServeBaseUrl;
    }());
    /**
     * Forguncy文件项
     */
    var ServerFileItem = /** @class */ (function (_super) {
        __extends(ServerFileItem, _super);
        function ServerFileItem(raw) {
            var _this = _super.call(this, Forguncy.Helper.SpecialPath.getFileDownloadUrl(raw, false)) || this;
            _this.raw = raw;
            return _this;
        }
        ServerFileItem.prototype.getEncodeURIComponentSrc = function () {
            return Forguncy.Helper.SpecialPath.getFileDownloadUrl(this.raw);
        };
        ServerFileItem.prototype.getStorageSrc = function () {
            return this.raw;
        };
        ServerFileItem.prototype.getFileName = function () {
            return this.raw;
        };
        ServerFileItem.prototype.getDisplayFileName = function () {
            // Length of Guid: 36 
            // Length of Underline: 1
            // Sample: cc614c5d-bb1a-4e1e-9b96-ed804c4cf73d_sample.png
            return this.getFileName().slice(37);
        };
        ServerFileItem.prototype.getKKFileAccessUrl = function () {
            return ServeBaseUrl.getAccessUrl() + this.raw;
        };
        return ServerFileItem;
    }(FilePreviewer.FileItem));
    FilePreviewer.ServerFileItem = ServerFileItem;
    /**
     * 服务器存储服务
     */
    var ServerStorageService = /** @class */ (function () {
        function ServerStorageService(metadata) {
            this.metadata = metadata;
            if (!this.metadata.UploadLimit) {
                this.metadata.UploadLimit = {
                    ExtensionFilter: "",
                    MaxUploadFileCount: null,
                    SizeLimit: null
                };
            }
        }
        ServerStorageService.prototype.upload = function (file, transmit) {
            //If the user does not want to upload image to server, he can upload image to another place and then return replaced url.
            //If the function result is false, it will still upload image to server, otherwise, it will upload image to another place.
            //Usage:
            //Forguncy.onFilePreviewerFileUpload = function (transmit, file, cellNames) {
            //    return true;
            //}
            if (Forguncy.onFilePreviewerFileUpload) {
                var result = Forguncy.onFilePreviewerFileUpload.call(this, transmit, file, this.metadata.CellNames);
                if (result) {
                    return;
                }
            }
            this.uploadFileWithAjax(file, transmit);
        };
        ServerStorageService.prototype.download = function (url, onSuccess, onError) {
            var link;
            if (FilePreviewer.PlatformInfo.isWeChat()) {
                link = $("<a>download</a>").attr("href", FilePreviewer.UrlHelper.getUrlWithTimestamp(url));
            }
            else {
                link = $("<a download>download</a>").attr("href", url);
            }
            $("body").append(link);
            link[0].click();
            link.remove();
            onSuccess && onSuccess();
        };
        ServerStorageService.prototype.delete = function (url, onSuccess, onError) {
            onSuccess && onSuccess();
        };
        ServerStorageService.prototype.uploadFileWithAjax = function (file, transmit) {
            var _a;
            var formData = new FormData();
            formData.append("file", file);
            formData.append("uploadLimitId", (_a = this.metadata.ServerPropertiesId) === null || _a === void 0 ? void 0 : _a.UploadLimit);
            $.ajax({
                url: ServeBaseUrl.getUploadUrl(),
                type: "POST",
                success: function (data, textStatus, jqXHR) { return transmit.success && transmit.success({ raw: file, fileItem: new ServerFileItem(jqXHR.responseText) }); },
                error: function (jqXHR, textStatus, errorThrown) { return transmit.fail && transmit.fail({ raw: file, errorMessage: ((jqXHR === null || jqXHR === void 0 ? void 0 : jqXHR.status) === 413) ? FilePreviewer.Resources.RequestEntityTooLargeUpload : errorThrown }); },
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                headers: {
                    "Accept": "application/json"
                },
                xhr: function () {
                    var xhr = $.ajaxSettings.xhr();
                    if (transmit.progress && xhr.upload) {
                        xhr.upload.addEventListener("progress", function (e) {
                            transmit.progress({ raw: file, loaded: e.loaded, total: e.total });
                        }, false);
                    }
                    return xhr;
                }
            });
        };
        return ServerStorageService;
    }());
    FilePreviewer.ServerStorageService = ServerStorageService;
})(FilePreviewer || (FilePreviewer = {}));
