var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Forguncy;
(function (Forguncy) {
    var HtmlRichEditor;
    (function (HtmlRichEditor_1) {
        var loadCssFileFulfillCb;
        var loadCssFilePromise = new Promise(function (resolve, reject) {
            loadCssFileFulfillCb = resolve;
        });
        //该css文件会引用相对路径下的字体，所以不能通过PluginConfig引用
        if ($("link[href*=\"/summernote/summernote-lite.css\"]").length === 0) {
            var cssSrc = Forguncy.Helper.SpecialPath.getPluginRootPath("6ce61862-5a45-45c0-a57e-9ad2f2794226") + "Resources/summernote/summernote-lite.css";
            var link = document.createElement('link');
            link.rel = "stylesheet";
            link.type = "text/css";
            link.href = cssSrc;
            link.onload = function () {
                loadCssFileFulfillCb();
            };
            document.head.appendChild(link);
        }
        var HtmlRichEditor = /** @class */ (function (_super) {
            __extends(HtmlRichEditor, _super);
            function HtmlRichEditor() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            HtmlRichEditor.prototype.createContent = function () {
                var container = $("<div class=\"FGCHtmlRichEditor\" style=\"height:100%\"></div>");
                var hiddenDom = $("<div id=".concat(this.ID + "_" + this["_pageID"], " style=\"display:none;\"></div>"));
                container.append(hiddenDom);
                this._contaienr = container;
                return container;
            };
            HtmlRichEditor.prototype.editor = function () {
                return $("#" + this.ID + "_" + this["_pageID"]);
            };
            HtmlRichEditor.prototype.getValueFromElement = function () {
                if (this._destroyed) {
                    return;
                }
                var isEmpty = this.editor().summernote("isEmpty");
                if (isEmpty) {
                    return null;
                }
                if (this.CellElement.CellType.StrictSecurityMode) {
                    var safeHtml = DOMPurify.sanitize(this.editor().summernote('code'));
                    this.outputHtmlContentRemoved();
                    return safeHtml;
                }
                else {
                    return this.editor().summernote('code');
                }
            };
            HtmlRichEditor.prototype.setValueToElement = function (element, value) {
                if (this._destroyed) {
                    return;
                }
                if (typeof value === "string") {
                    if (this.CellElement.CellType.StrictSecurityMode) {
                        value = DOMPurify.sanitize(value);
                        this.outputHtmlContentRemoved();
                    }
                    else {
                        value = value.replace(/<[\r|\n|\s]*script[\r|\n|\s]*/gi, "&lt;script");
                    }
                }
                var currentValue = this.getValueFromElement();
                if (currentValue === value) {
                    return;
                }
                this.editor().summernote('code', value);
            };
            HtmlRichEditor.prototype.outputHtmlContentRemoved = function () {
                var _a;
                if (!Forguncy.StaticData.IsDebugMode) {
                    return;
                }
                if (DOMPurify.removed && DOMPurify.removed.length > 0) {
                    var tips = (_a = {},
                        _a["en" /* Forguncy.ForguncySupportCultures.English */] = "Removed potentially harmful content.",
                        _a["cn" /* Forguncy.ForguncySupportCultures.Chinese */] = "移除了可能有害的内容。",
                        _a["ja" /* Forguncy.ForguncySupportCultures.Japanese */] = "有害かもしれない内容を削除しました。",
                        _a["kr" /* Forguncy.ForguncySupportCultures.Korean */] = "유해할 수 있는 내용을 제거했습니다.",
                        _a);
                    var locationStr = Forguncy.FormulaHelper.getCellLogLocationString(this.ID, this.Name, this.runTimePageName);
                    console.warn(tips[Forguncy.RS.Culture], locationStr, DOMPurify.removed);
                }
            };
            HtmlRichEditor.prototype.hasFocus = function () {
                return this._hasFocus;
            };
            HtmlRichEditor.prototype.setFocus = function () {
                if (this.isReadOnly()) {
                    return;
                }
                this.editor().summernote("focus");
            };
            HtmlRichEditor.prototype.disable = function () {
                _super.prototype.disable.call(this);
                this.updateEditorMode();
            };
            HtmlRichEditor.prototype.enable = function () {
                _super.prototype.enable.call(this);
                this.updateEditorMode();
            };
            HtmlRichEditor.prototype.setReadOnly = function (value) {
                _super.prototype.setReadOnly.call(this, value);
                if (this._summernoteCreated) {
                    this.updateEditorMode();
                }
            };
            HtmlRichEditor.prototype.updateEditorMode = function () {
                var editor = this.editor();
                if (!editor) {
                    return;
                }
                var mode = (this.isDisabled() || this.isReadOnly()) ? 'disable' : 'enable';
                editor.summernote(mode);
            };
            HtmlRichEditor.prototype.destroy = function () {
                //Usage:
                //Forguncy.onHtmlRichEditorDestroying = function () {
                //    console.log('onHtmlRichEditorDestroying');
                //}
                if (Forguncy.onHtmlRichEditorDestroying) {
                    Forguncy.onHtmlRichEditorDestroying.call(this);
                }
                this._destroyed = true;
                this.editor().summernote('destroy');
            };
            HtmlRichEditor.prototype.onLoad = function () {
                var _this = this;
                var cellTypeMetadata = this.CellElement.CellType;
                var showToolBars = cellTypeMetadata.ShowToolBars;
                //If the user does not want to convert image to base64, he can upload image to another place and then return replaced url.
                //Usage:
                //Forguncy.onHtmlRichEditorImageUpload = function (editor, files) {
                //    var fileUrl = ""; //Convert files[0] to url.
                //    editor.summernote("insertImage", fileUrl);
                //}
                var onImageUploadMethod;
                if (Forguncy.onHtmlRichEditorImageUpload) {
                    var editor_1 = this.editor();
                    onImageUploadMethod = function (files) {
                        Forguncy.onHtmlRichEditorImageUpload.call(_this, editor_1, files);
                    };
                }
                //Usage:
                //Forguncy.onHtmlRichEditorChanged = function (contents, $editable) {
                //    console.log('onChange:', contents, $editable);
                //}
                var onEditorChangedMethod;
                if (Forguncy.onHtmlRichEditorChanged) {
                    onEditorChangedMethod = function (contents, $editable) {
                        Forguncy.onHtmlRichEditorChanged.call(_this, contents, $editable);
                    };
                }
                this.initSummernoteResource();
                this.editor().summernote({
                    lang: Forguncy.RS.Culture,
                    toolbar: [
                        ['operation', ['undo', 'redo',]],
                        ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript',]],
                        ['fontname', [this.isMobile() ? '' : 'fontname', 'fontsize']],
                        ['color', ['color', 'clear',]],
                        ['Paragraph style', ['style', 'ul', 'ol', 'paragraph', 'height']],
                        ['insert', ['hr', 'link', 'picture', 'video', 'table']],
                        ['view', ['codeview', 'help']]
                    ],
                    fontSizes: ['8', '9', '10', '11', '12', '14', '16', '18', '24', '36'],
                    popover: {
                        image: [
                            ['resize', ['resizeFull', 'resizeHalf', 'resizeQuarter', 'resizeNone']],
                            ['float', ['floatLeft', 'floatRight', 'floatNone']],
                            ['remove', ['removeMedia']],
                        ],
                        link: [
                            ['link', ['linkDialogShow', 'unlink']],
                        ],
                        table: [
                            ['add', ['addRowDown', 'addRowUp', 'addColLeft', 'addColRight']],
                            ['delete', ['deleteRow', 'deleteCol', 'deleteTable']],
                        ],
                        air: [
                            ['color', ['color']],
                            ['font', ['bold', 'underline', 'clear']],
                            ['para', ['ul', 'ol', 'paragraph']],
                            ['table', ['table']],
                            ['insert', ['link', 'picture']],
                        ]
                    },
                    airMode: !showToolBars,
                    disableResizeEditor: true,
                    disableDragAndDrop: true,
                    callbacks: {
                        onInit: function () {
                            _this._contaienr.css("opacity", 0);
                        },
                        onFocus: function () {
                            _this._hasFocus = true;
                        },
                        onBlur: function () {
                            _this._hasFocus = false;
                            _this.commitValue();
                            if (!_this.isReadOnly()) {
                                _this.validate();
                            }
                        },
                        onBlurCodeview: function () {
                            _this._hasFocus = false;
                            _this.commitValue();
                            if (!_this.isReadOnly()) {
                                _this.validate();
                            }
                        },
                        onImageUpload: onImageUploadMethod,
                        onChange: onEditorChangedMethod
                    },
                });
                this._summernoteCreated = true;
                //add data-id for autoTesting
                var noteEditable = this.editor().siblings(".note-editor").find(".note-editable");
                noteEditable.attr("data-id", this.ID);
                this.updateEditorMode();
                loadCssFilePromise.then(function () {
                    _this._contaienr.css("opacity", 1);
                });
                if (this.isDesignerPreview) {
                    var helpTextForPage = this.designerPreviewCustomArgs[0];
                    if (helpTextForPage) {
                        this.editor().summernote("code", "<span style='font-size: 13px'>" + helpTextForPage + "</span>");
                    }
                }
            };
            HtmlRichEditor.prototype.initSummernoteResource = function () {
                var _a;
                $.extend($.summernote.lang, (_a = {},
                    _a[Forguncy.RS.Culture] = {
                        font: {
                            bold: this.getPluginResource("font.bold"),
                            italic: this.getPluginResource("font.italic"),
                            underline: this.getPluginResource("font.underline"),
                            clear: this.getPluginResource("font.clear"),
                            height: this.getPluginResource("font.height"),
                            name: this.getPluginResource("font.name"),
                            strikethrough: this.getPluginResource("font.strikethrough"),
                            subscript: this.getPluginResource("font.subscript"),
                            superscript: this.getPluginResource("font.superscript"),
                            size: this.getPluginResource("font.size"),
                            sizeunit: this.getPluginResource("font.sizeunit")
                        },
                        image: {
                            image: this.getPluginResource("image.image"),
                            insert: this.getPluginResource("image.insert"),
                            resizeFull: this.getPluginResource("image.resizeFull"),
                            resizeHalf: this.getPluginResource("image.resizeHalf"),
                            resizeQuarter: this.getPluginResource("image.resizeQuarter"),
                            resizeNone: this.getPluginResource("image.resizeNone"),
                            floatLeft: this.getPluginResource("image.floatLeft"),
                            floatRight: this.getPluginResource("image.floatRight"),
                            floatNone: this.getPluginResource("image.floatNone"),
                            shapeRounded: this.getPluginResource("image.shapeRounded"),
                            shapeCircle: this.getPluginResource("image.shapeCircle"),
                            shapeThumbnail: this.getPluginResource("image.shapeThumbnail"),
                            shapeNone: this.getPluginResource("image.shapeNone"),
                            dragImageHere: this.getPluginResource("image.dragImageHere"),
                            dropImage: this.getPluginResource("image.dropImage"),
                            selectFromFiles: this.getPluginResource("image.selectFromFiles"),
                            maximumFileSize: this.getPluginResource("image.maximumFileSize"),
                            maximumFileSizeError: this.getPluginResource("image.maximumFileSizeError"),
                            url: this.getPluginResource("image.url"),
                            remove: this.getPluginResource("image.remove"),
                            original: this.getPluginResource("image.original"),
                        },
                        video: {
                            video: this.getPluginResource("video.video"),
                            videoLink: this.getPluginResource("video.videoLink"),
                            insert: this.getPluginResource("video.insert"),
                            url: this.getPluginResource("video.url"),
                            providers: this.getPluginResource("video.providers")
                        },
                        link: {
                            link: this.getPluginResource("link.link"),
                            insert: this.getPluginResource("link.insert"),
                            unlink: this.getPluginResource("link.unlink"),
                            edit: this.getPluginResource("link.edit"),
                            textToDisplay: this.getPluginResource("link.textToDisplay"),
                            url: this.getPluginResource("link.url"),
                            openInNewWindow: this.getPluginResource("link.openInNewWindow"),
                            useProtocol: this.getPluginResource("link.useProtocol")
                        },
                        table: {
                            table: this.getPluginResource("table.table"),
                            addRowAbove: this.getPluginResource("table.addRowAbove"),
                            addRowBelow: this.getPluginResource("table.addRowBelow"),
                            addColLeft: this.getPluginResource("table.addColLeft"),
                            addColRight: this.getPluginResource("table.addColRight"),
                            delRow: this.getPluginResource("table.delRow"),
                            delCol: this.getPluginResource("table.delCol"),
                            delTable: this.getPluginResource("table.delTable")
                        },
                        hr: {
                            insert: this.getPluginResource("hr.insert")
                        },
                        style: {
                            style: this.getPluginResource("style.style"),
                            p: this.getPluginResource("style.p"),
                            blockquote: this.getPluginResource("style.blockquote"),
                            pre: this.getPluginResource("style.pre"),
                            h1: this.getPluginResource("style.h1"),
                            h2: this.getPluginResource("style.h2"),
                            h3: this.getPluginResource("style.h3"),
                            h4: this.getPluginResource("style.h4"),
                            h5: this.getPluginResource("style.h5"),
                            h6: this.getPluginResource("style.h6"),
                        },
                        lists: {
                            unordered: this.getPluginResource("lists.unordered"),
                            ordered: this.getPluginResource("lists.ordered"),
                        },
                        options: {
                            help: this.getPluginResource("options.help"),
                            fullscreen: this.getPluginResource("options.fullscreen"),
                            codeview: this.getPluginResource("options.codeview"),
                        },
                        paragraph: {
                            paragraph: this.getPluginResource("paragraph.paragraph"),
                            outdent: this.getPluginResource("paragraph.outdent"),
                            indent: this.getPluginResource("paragraph.indent"),
                            left: this.getPluginResource("paragraph.left"),
                            center: this.getPluginResource("paragraph.center"),
                            right: this.getPluginResource("paragraph.right"),
                            justify: this.getPluginResource("paragraph.justify"),
                        },
                        color: {
                            recent: this.getPluginResource("color.recent"),
                            more: this.getPluginResource("color.more"),
                            background: this.getPluginResource("color.background"),
                            foreground: this.getPluginResource("color.foreground"),
                            transparent: this.getPluginResource("color.transparent"),
                            setTransparent: this.getPluginResource("color.setTransparent"),
                            reset: this.getPluginResource("color.reset"),
                            resetToDefault: this.getPluginResource("color.resetToDefault"),
                            cpSelect: this.getPluginResource("color.cpSelect"),
                        },
                        shortcut: {
                            shortcuts: this.getPluginResource("shortcut.cpSelect"),
                            close: this.getPluginResource("shortcut.close"),
                            textFormatting: this.getPluginResource("shortcut.textFormatting"),
                            action: this.getPluginResource("shortcut.action"),
                            paragraphFormatting: this.getPluginResource("shortcut.paragraphFormatting"),
                            documentStyle: this.getPluginResource("shortcut.documentStyle"),
                            extraKeys: this.getPluginResource("shortcut.extraKeys"),
                        },
                        help: {
                            'insertParagraph': this.getPluginResource("help.insertParagraph"),
                            'undo': this.getPluginResource("help.undo"),
                            'redo': this.getPluginResource("help.redo"),
                            'tab': this.getPluginResource("help.tab"),
                            'untab': this.getPluginResource("help.untab"),
                            'bold': this.getPluginResource("help.bold"),
                            'italic': this.getPluginResource("help.italic"),
                            'underline': this.getPluginResource("help.underline"),
                            'strikethrough': this.getPluginResource("help.strikethrough"),
                            'removeFormat': this.getPluginResource("help.removeFormat"),
                            'justifyLeft': this.getPluginResource("help.justifyLeft"),
                            'justifyCenter': this.getPluginResource("help.justifyCenter"),
                            'justifyRight': this.getPluginResource("help.justifyRight"),
                            'justifyFull': this.getPluginResource("help.justifyFull"),
                            'insertUnorderedList': this.getPluginResource("help.insertUnorderedList"),
                            'insertOrderedList': this.getPluginResource("help.insertOrderedList"),
                            'outdent': this.getPluginResource("help.outdent"),
                            'indent': this.getPluginResource("help.indent"),
                            'formatPara': this.getPluginResource("help.formatPara"),
                            'formatH1': this.getPluginResource("help.formatH1"),
                            'formatH2': this.getPluginResource("help.formatH2"),
                            'formatH3': this.getPluginResource("help.formatH3"),
                            'formatH4': this.getPluginResource("help.formatH4"),
                            'formatH5': this.getPluginResource("help.formatH5"),
                            'formatH6': this.getPluginResource("help.formatH6"),
                            'insertHorizontalRule': this.getPluginResource("help.escape"),
                            'linkDialog.show': this.getPluginResource("help.linkDialog.show"),
                            escape: this.getPluginResource("help.escape")
                        },
                        history: {
                            undo: this.getPluginResource("history.undo"),
                            redo: this.getPluginResource("history.redo"),
                        },
                        specialChar: {
                            specialChar: this.getPluginResource("specialChar.specialChar"),
                            select: this.getPluginResource("specialChar.select"),
                        },
                        output: {
                            noSelection: this.getPluginResource("output.noSelection")
                        }
                    },
                    _a));
            };
            HtmlRichEditor.prototype.isMobile = function () {
                //Code source: http://stackoverflow.com/questions/3514784/what-is-the-best-way-to-detect-a-mobile-device-in-jquery
                if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent)
                    || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0, 4))) {
                    return true;
                }
                return false;
            };
            HtmlRichEditor.prototype._setOverflowHidden = function () {
                // Do Nothing
            };
            HtmlRichEditor.prototype.setTabIndexToElement = function (tabIndex) {
                var element = this.editor().siblings(".note-editor").find(".note-editable");
                if (tabIndex === 0) {
                    element.removeAttr("tabindex");
                }
                else {
                    element.attr("tabindex", tabIndex);
                }
            };
            return HtmlRichEditor;
        }(Forguncy.Plugin.CellTypeBase));
        HtmlRichEditor_1.HtmlRichEditor = HtmlRichEditor;
    })(HtmlRichEditor = Forguncy.HtmlRichEditor || (Forguncy.HtmlRichEditor = {}));
})(Forguncy || (Forguncy = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("HtmlRichEditor.HtmlRichEditor, HtmlRichEditor", Forguncy.HtmlRichEditor.HtmlRichEditor);
