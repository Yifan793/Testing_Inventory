var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var PassListviewDataCommand;
(function (PassListviewDataCommand_1) {
    var PassListviewDataCommand = /** @class */ (function (_super) {
        __extends(PassListviewDataCommand, _super);
        function PassListviewDataCommand() {
            var _this = _super.call(this) || this;
            if (!PassListviewDataCommand.hasBindPageEvent) {
                PassListviewDataCommand.hasBindPageEvent = true;
                Forguncy.Page.bind(Forguncy.PageEvents.PageDefaultDataLoaded, PassListviewDataCommand.onCurrentPageChanged, "*");
                Forguncy.Page.bind(Forguncy.PageEvents.PopupClosed, PassListviewDataCommand.onCurrentPageChanged, "*");
            }
            return _this;
        }
        PassListviewDataCommand.onCurrentPageChanged = function (arg1, arg2) {
            PassListviewDataCommand.cache.forEach(function (data) {
                return PassListviewDataCommand.tryToPassDataToCurrentPage(data, null);
            });
            PassListviewDataCommand.cache = [];
        };
        PassListviewDataCommand.prototype.execute = function () {
            var _a;
            var commandSettings = this.CommandParam;
            var passItems = commandSettings.PassValueItems;
            if (!passItems || passItems.length === 0) {
                return;
            }
            var sourceCells = this.getSourceCellInfos(passItems);
            var sourceListview = this.getSourceListview(commandSettings.Source);
            if (!sourceListview) {
                return;
            }
            var sourceListviewData = this.getSourceListviewData(sourceListview, sourceCells, commandSettings.PassRowMode);
            if (sourceListviewData.length === 0 &&
                commandSettings.ImportMode !== Forguncy.ImportMode.Replace &&
                commandSettings.ImportMode !== Forguncy.ImportMode.ReplaceIgnoreEdit) {
                return;
            }
            var targetExpr = ((_a = commandSettings.Target) === null || _a === void 0 ? void 0 : _a.startsWith("=")) && commandSettings.TargetPage ? "='".concat(commandSettings.TargetPage, "'!").concat(commandSettings.Target.substring(1)) : commandSettings.Target;
            var passDataInfo = {
                TargetPage: commandSettings.TargetPage,
                TargetCells: this.getTargetCellInfos(passItems),
                Data: sourceListviewData,
                ImportMode: commandSettings.ImportMode,
                TargetCellLocation: this.getCellLocation(targetExpr)
            };
            var success = PassListviewDataCommand.tryToPassDataToCurrentPage(passDataInfo, sourceListview);
            if (!success) {
                PassListviewDataCommand.cache.push(passDataInfo);
            }
        };
        PassListviewDataCommand.prototype.getSourceCellInfos = function (passItems) {
            var _this = this;
            return passItems.map(function (item) { return ({
                Cell: _this.getCellLocationOrColumnName(item.SourceCell),
                IsPrimaryKey: item.IsPrimaryKey
            }); });
        };
        PassListviewDataCommand.prototype.getTargetCellInfos = function (passItems) {
            var _this = this;
            return passItems.map(function (item) { return ({
                Cell: _this.getCellLocationOrColumnName(item.TargetCell),
                IsPrimaryKey: item.IsPrimaryKey
            }); });
        };
        PassListviewDataCommand.prototype.getCellLocationOrColumnName = function (cell) {
            var isFormula = typeof (cell) === "string" && cell.length > 0 && cell.startsWith("=");
            if (isFormula) {
                return this.getCellLocation(cell);
            }
            else {
                return cell;
            }
        };
        PassListviewDataCommand.tryToPassDataToCurrentPage = function (passDataInfo, excludeListview) {
            if (PassListviewDataCommand.isTargetListviewInCurrentPage(passDataInfo, excludeListview)) {
                PassListviewDataCommand.addDataToTargetListview(passDataInfo, null, excludeListview);
                return true;
            }
            var subPageInfo = PassListviewDataCommand.getTargetSubPageInfo(passDataInfo, null, excludeListview);
            if (subPageInfo) {
                PassListviewDataCommand.addDataToTargetListview(passDataInfo, subPageInfo, excludeListview);
                return true;
            }
            return false;
        };
        PassListviewDataCommand.isTargetListviewInCurrentPage = function (passDataInfo, excludeListview) {
            if (Forguncy.Page.getPageName() === passDataInfo.TargetPage) {
                return true;
            }
            if (!passDataInfo.TargetPage) {
                return !!PassListviewDataCommand.getTargetListview(passDataInfo.TargetCellLocation, passDataInfo.TargetCells, passDataInfo.ImportMode, null, excludeListview);
            }
            return false;
        };
        PassListviewDataCommand.getTargetSubPageInfo = function (passDataInfo, pageInfo, excludeListview) {
            var containers = pageInfo ? pageInfo.getContainerCells() : Forguncy.Page.getContainerCells(false);
            for (var _i = 0, containers_1 = containers; _i < containers_1.length; _i++) {
                var container = containers_1[_i];
                var subPageInfos = void 0;
                if (container.constructor === Forguncy.ContentContainerCell || container.constructor === Forguncy.UserControlPageCell) {
                    subPageInfos = PassListviewDataCommand.getSubPagesOfContentContainerCell(container);
                }
                else if (container.constructor === Forguncy.TabControlCell) {
                    subPageInfos = PassListviewDataCommand.getSubPagesOfTabControlCell(container);
                }
                else {
                    subPageInfos = [];
                }
                for (var _a = 0, subPageInfos_1 = subPageInfos; _a < subPageInfos_1.length; _a++) {
                    var subPageInfo = subPageInfos_1[_a];
                    if (PassListviewDataCommand.isTargetListviewInSubPage(passDataInfo, subPageInfo, excludeListview)) {
                        return subPageInfo;
                    }
                    var target = PassListviewDataCommand.getTargetSubPageInfo(passDataInfo, subPageInfo, excludeListview);
                    if (target) {
                        return target;
                    }
                }
            }
            return null;
        };
        PassListviewDataCommand.getSubPagesOfContentContainerCell = function (cell) {
            return [cell.getContentPage()];
        };
        PassListviewDataCommand.getSubPagesOfTabControlCell = function (cell) {
            var subPageInfos = [];
            var tabCount = cell.getTabCount();
            for (var k = 0; k < tabCount; k++) {
                subPageInfos.push(cell.getTabPage(k));
            }
            return subPageInfos;
        };
        PassListviewDataCommand.isTargetListviewInSubPage = function (passDataInfo, subPageInfo, excludeListview) {
            if (!subPageInfo) {
                return false;
            }
            if (subPageInfo.getPageName() === passDataInfo.TargetPage) {
                return true;
            }
            if (!passDataInfo.TargetPage) {
                return !!PassListviewDataCommand.getTargetListview(passDataInfo.TargetCellLocation, passDataInfo.TargetCells, passDataInfo.ImportMode, subPageInfo, excludeListview);
            }
        };
        PassListviewDataCommand.prototype.getSourceListview = function (source) {
            var pageID = this.getFormulaCalcContext().PageID;
            var listview = PassListviewDataCommand.getListviewByLocation(this.getCellLocation(source), Forguncy.Page.getSubPageInfoByPageID(pageID));
            return listview;
        };
        PassListviewDataCommand.prototype.getSourceListviewData = function (listview, sourceCells, passRowMode) {
            var columns = PassListviewDataCommand.getColumns(listview, sourceCells);
            switch (passRowMode) {
                case PassRowMode.SelectedRows:
                    return this.getSourceListviewDataOfSelectedRows(listview, columns);
                case PassRowMode.CurrentRow:
                    return this.getSourceListviewDataOfCurrentRow(listview, columns);
                default:
                    return this.getSourceListviewDataOfAllRows(listview, columns);
            }
        };
        PassListviewDataCommand.prototype.getSourceListviewDataOfSelectedRows = function (listview, columns) {
            var selectedRowsData = listview.getSelectedRowsData();
            return selectedRowsData.map(function (d) {
                return columns.map(function (c) {
                    if (c === -1) {
                        return null;
                    }
                    else {
                        return d.Values[c];
                    }
                });
            });
        };
        PassListviewDataCommand.prototype.getSourceListviewDataOfCurrentRow = function (listview, columns) {
            var currentRowIndex = listview.getSelectedRowIndex();
            var rowCount = listview.getRowCount();
            if (currentRowIndex === undefined || currentRowIndex < 0 || currentRowIndex >= rowCount) {
                return [];
            }
            return [this.getRowDataFromListview(listview, columns, currentRowIndex)];
        };
        PassListviewDataCommand.prototype.getSourceListviewDataOfAllRows = function (listview, columns) {
            var data = [];
            var rowCount = listview.getRowCount();
            for (var r = 0; r < rowCount; r++) {
                data.push(this.getRowDataFromListview(listview, columns, r));
            }
            return data;
        };
        PassListviewDataCommand.prototype.getRowDataFromListview = function (listview, columns, rowIndex) {
            return columns.map(function (c) {
                return c === -1 ? null : listview.getValue(rowIndex, c);
            });
        };
        PassListviewDataCommand.getListViewByListViewLocation = function (cellLocation, pageInfo) {
            var listViews = pageInfo ? pageInfo.getListViews() : Forguncy.Page.getListViews(false);
            for (var _i = 0, listViews_1 = listViews; _i < listViews_1.length; _i++) {
                var listview = listViews_1[_i];
                if (PassListviewDataCommand.isListviewContainCellLocation(listview, cellLocation)) {
                    return listview;
                }
            }
            return null;
        };
        PassListviewDataCommand.getListViewByRepeater = function (cellLocation, pageInfo) {
            var listViews = pageInfo ? pageInfo.getListViews() : Forguncy.Page.getListViews(false);
            var cell = pageInfo ? pageInfo.getCellByLocation(cellLocation, false) : Forguncy.Page.getCellByLocation(cellLocation, false);
            if (!cell) {
                return null;
            }
            var cellType = cell.getCellType().CellElement.CellType;
            if (cellType["$type"] === "Forguncy.RepeaterCellType, ServerDesignerCommon") {
                var listviewName_1 = cellType["RealListviewName"];
                return listViews.find(function (listview) { return listview.getName() === listviewName_1; });
            }
            return null;
        };
        //fix Forguncy-16822: 当指定目标的cellLocation时，target listview可以是source listview
        PassListviewDataCommand.getListviewByLocation = function (cellLocation, pageInfo) {
            if (!cellLocation) {
                return null;
            }
            var repeaterListView = PassListviewDataCommand.getListViewByRepeater(cellLocation, pageInfo);
            if (repeaterListView !== null) {
                //repeater
                return repeaterListView;
            }
            //listview
            return PassListviewDataCommand.getListViewByListViewLocation(cellLocation, pageInfo);
        };
        PassListviewDataCommand.getTargetListview = function (cellLocation, cells, importMode, pageInfo, excludeListview) {
            if (cellLocation) {
                return PassListviewDataCommand.getListviewByLocation(cellLocation, pageInfo);
            }
            var firstCellLocation;
            for (var _i = 0, cells_1 = cells; _i < cells_1.length; _i++) {
                var element = cells_1[_i];
                if (typeof (element.Cell) === "object") {
                    firstCellLocation = element.Cell;
                    break;
                }
            }
            var primaryColumnNames = [];
            for (var _a = 0, cells_2 = cells; _a < cells_2.length; _a++) {
                var element = cells_2[_a];
                if (typeof (element.Cell) === "string" && element.Cell) {
                    if (importMode === Forguncy.ImportMode.Add) {
                        primaryColumnNames.push(element.Cell);
                        break;
                    }
                    else {
                        if (element.IsPrimaryKey) {
                            primaryColumnNames.push(element.Cell);
                        }
                    }
                }
            }
            if (!firstCellLocation && primaryColumnNames.length <= 0) {
                return null;
            }
            var listViews = pageInfo ? pageInfo.getListViews() : Forguncy.Page.getListViews(false);
            var _loop_1 = function (element) {
                if (firstCellLocation) {
                    if (PassListviewDataCommand.isListviewContainCellLocation(element, firstCellLocation)) {
                        return { value: element };
                    }
                }
                else if (primaryColumnNames) {
                    if (primaryColumnNames.every(function (name) { return PassListviewDataCommand.getColumnIndex(element, name) !== -1; })) {
                        if (excludeListview && element === excludeListview) {
                            return "continue";
                        }
                        else {
                            return { value: element };
                        }
                    }
                }
            };
            for (var _b = 0, listViews_2 = listViews; _b < listViews_2.length; _b++) {
                var element = listViews_2[_b];
                var state_1 = _loop_1(element);
                if (typeof state_1 === "object")
                    return state_1.value;
            }
            return null;
        };
        PassListviewDataCommand.isListviewContainCellLocation = function (listview, cellLocation) {
            var rangeInfo = listview.getDesignerRangeInfo();
            return cellLocation.Row >= rangeInfo.Row &&
                cellLocation.Row < rangeInfo.Row + rangeInfo.RowCount &&
                cellLocation.Column >= rangeInfo.Column &&
                cellLocation.Column < rangeInfo.Column + rangeInfo.ColumnCount;
        };
        PassListviewDataCommand.getColumnIndex = function (listview, cell) {
            var columns = listview.getMergedColumnInfos();
            if (!cell) {
                return -1;
            }
            else if (typeof (cell) === "string") {
                for (var i = 0; i < columns.length; i++) {
                    if (columns[i].ColumnName === cell) {
                        return i;
                    }
                }
                return -1;
            }
            else {
                for (var i = 0; i < columns.length; i++) {
                    if (columns[i].DesignerColumnIndex === cell.Column) {
                        return i;
                    }
                }
                return -1;
            }
        };
        PassListviewDataCommand.getColumns = function (listview, cells) {
            var columns = [];
            for (var _i = 0, cells_3 = cells; _i < cells_3.length; _i++) {
                var element = cells_3[_i];
                columns.push(PassListviewDataCommand.getColumnIndex(listview, element.Cell));
            }
            return columns;
        };
        PassListviewDataCommand.addDataToTargetListview = function (passDataInfo, pageInfo, excludeListview) {
            var _this = this;
            var listview = PassListviewDataCommand.getTargetListview(passDataInfo.TargetCellLocation, passDataInfo.TargetCells, passDataInfo.ImportMode, pageInfo, excludeListview);
            if (!listview) {
                return;
            }
            var columns = PassListviewDataCommand.getColumns(listview, passDataInfo.TargetCells);
            var data = [];
            for (var _i = 0, _a = passDataInfo.Data; _i < _a.length; _i++) {
                var element = _a[_i];
                var rowData = [];
                for (var c = 0; c < columns.length; c++) {
                    if (columns[c] === -1) {
                        continue;
                    }
                    rowData[columns[c]] = element[c];
                }
                data.push(rowData);
            }
            var baseColumns = passDataInfo.TargetCells
                .map(function (cell, index) { return cell.IsPrimaryKey ? columns[index] : -1; })
                .filter(function (index) { return index !== -1; });
            var editColumns = columns.filter(function (i) { return i !== -1; });
            listview.importData(data, false, passDataInfo.ImportMode, baseColumns, editColumns, function (result) {
                _this.handleErrorInfo(result);
            });
        };
        PassListviewDataCommand.handleErrorInfo = function (result) {
            if (result.Success) {
                return;
            }
            switch (result.ErrorInfos[0].ErrorType) {
                case Forguncy.ImportError.ExistEmptyKeys:
                    alert(PassListviewDataCommand_1.RSHelper.getRS().Error_ExistEmptyKeys);
                    break;
                case Forguncy.ImportError.ExistSameKeys:
                    alert(PassListviewDataCommand_1.RSHelper.getRS().Error_ExistSameKeys);
                    break;
                default:
                    break;
            }
        };
        PassListviewDataCommand.hasBindPageEvent = false;
        PassListviewDataCommand.cache = [];
        return PassListviewDataCommand;
    }(Forguncy.Plugin.CommandBase));
    PassListviewDataCommand_1.PassListviewDataCommand = PassListviewDataCommand;
    var PassRowMode;
    (function (PassRowMode) {
        PassRowMode[PassRowMode["AllRows"] = 0] = "AllRows";
        PassRowMode[PassRowMode["SelectedRows"] = 1] = "SelectedRows";
        PassRowMode[PassRowMode["CurrentRow"] = 2] = "CurrentRow";
    })(PassRowMode || (PassRowMode = {}));
})(PassListviewDataCommand || (PassListviewDataCommand = {}));
Forguncy.Plugin.CommandFactory.registerCommand("PassListviewDataCommand.PassListviewDataCommand, PassListviewDataCommand", PassListviewDataCommand.PassListviewDataCommand);
//# sourceMappingURL=PassListviewDataCommand.js.map