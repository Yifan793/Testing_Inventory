var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var TabManager;
(function (TabManager) {
    /**
     * UserControl具备这样的能力，即，当它已注册的属性的值被修改时，会dispatch相应的PropertyChanged事件
     * 这提供了这样的基础：当修改UserControl的注册属性时，可以通过UserControlEvents.PropertyChanged事件，通知到别处
     */
    var UserControl = /** @class */ (function (_super) {
        __extends(UserControl, _super);
        function UserControl() {
            var _this = _super.call(this) || this;
            _this.enabled = true;
            _this.visibility = true;
            _this.focusable = false;
            _this.isFocus = false;
            _this.registedProperties = [];
            _this.registDefaultProperties();
            return _this;
        }
        UserControl.prototype.refresh = function () {
            this.dispatch("Refresh" /* UserControlEvents.Refresh */);
            return this;
        };
        UserControl.prototype.identify = function (id) {
            this.id = id;
            return this;
        };
        UserControl.prototype.show = function () {
            this.refresh();
            this.visibility = true;
            return this;
        };
        UserControl.prototype.hide = function () {
            this.visibility = false;
            return this;
        };
        UserControl.prototype.focus = function () {
            this.isFocus = true;
            return this;
        };
        UserControl.prototype.blur = function () {
            this.isFocus = false;
            return this;
        };
        UserControl.prototype.enable = function () {
            this.enabled = true;
            return this;
        };
        UserControl.prototype.disable = function () {
            this.enabled = false;
            return this;
        };
        UserControl.prototype.createUI = function (uiConstructor) {
            if (uiConstructor === void 0) { uiConstructor = this.defaultUI; }
            return new uiConstructor(this);
        };
        UserControl.prototype.bindProperty = function (targetElement, targetName, sourceName) {
            var _this = this;
            // Regist source name
            if (this.registedProperties.indexOf(sourceName) < 0) {
                this.registProperty(sourceName);
            }
            // Regist target name
            if (targetElement.registedProperties.indexOf(targetName) < 0) {
                targetElement.registProperty(targetName);
            }
            // Sync value immediately
            targetElement[targetName] = this[sourceName];
            // Bind target value
            targetElement.on("PropertyChanged" /* UserControlEvents.PropertyChanged */, function (data, propertyName) {
                if (propertyName === targetName && targetElement) {
                    _this[sourceName] = targetElement[targetName];
                }
            });
            // Bind source value
            this.on("PropertyChanged" /* UserControlEvents.PropertyChanged */, function (data, propertyName) {
                if (propertyName === sourceName && targetElement) {
                    targetElement[targetName] = _this[sourceName];
                }
            });
        };
        UserControl.prototype.registProperty = function (propertyName, value) {
            if (value === void 0) { value = this[propertyName]; }
            var self = this;
            var privatePropertyName = "__".concat(propertyName.toString());
            this[privatePropertyName] = value;
            // 这里 相对于把原来的属性propertyName 强制修改为访问器属性了
            Object.defineProperty(this, propertyName, {
                get: function () {
                    return self[privatePropertyName];
                },
                set: function (newValue) {
                    if (newValue !== self[privatePropertyName]) {
                        self[privatePropertyName] = newValue;
                        self.onPropertyChanged(propertyName);
                    }
                }
            });
            this.registedProperties.push(propertyName);
        };
        UserControl.prototype.registDefaultProperties = function () {
            this.registProperty("id");
            this.registProperty("enabled");
            this.registProperty("visibility");
            this.registProperty("focusable");
            this.registProperty("isFocus");
        };
        UserControl.prototype.onPropertyChanged = function (propertyName) {
            this.dispatch("PropertyChanged" /* UserControlEvents.PropertyChanged */, propertyName);
        };
        return UserControl;
    }(TabManager.EventDispatcher));
    TabManager.UserControl = UserControl;
    var JQueryUIBase = /** @class */ (function () {
        //modifiers: UIModifier<this>[];
        function JQueryUIBase(target) {
            this.target = target;
            this.createContainer();
            this.createContainerEvents();
            this.refresh();
        }
        // IJQueryUI.refresh()
        JQueryUIBase.prototype.refresh = function () {
            this.container.empty();
            this.createChildren();
            return this;
        };
        // IJQueryUI.dispose
        JQueryUIBase.prototype.dispose = function () { };
        JQueryUIBase.prototype.createChildren = function () { };
        JQueryUIBase.prototype.createContainer = function () {
            this.container = $('<div></div>');
        };
        JQueryUIBase.prototype.createContainerEvents = function () { };
        JQueryUIBase.prototype.addChild = function (jqueryUI, targetContainer) {
            if (targetContainer === void 0) { targetContainer = this.container; }
            if (jqueryUI && targetContainer) {
                targetContainer.append(jqueryUI.container);
            }
        };
        return JQueryUIBase;
    }());
    TabManager.JQueryUIBase = JQueryUIBase;
    /**
     * 1.在ControlUIBase中，添加与T中已注册的属性同名的访问器属性，在其set方法里，做特定操作，比如，UI相关操作
     * 2.在ControlUIBase基类的构造函数中，绑定T的PropertyChanged事件，使得当修改T中的已注册属性时，能通过事件
     * 接收到这种改动，在事件中设置ControlUIBase的同名访问属性。这就实现了T中已注册的属性和UI的某种绑定
     */
    var ControlUIBase = /** @class */ (function (_super) {
        __extends(ControlUIBase, _super);
        function ControlUIBase(target) {
            var _this = _super.call(this, target) || this;
            _this.target.on("Refresh" /* UserControlEvents.Refresh */, function () {
                _this.refresh();
            });
            _this.target.on("PropertyChanged" /* UserControlEvents.PropertyChanged */, function (propertyName) {
                _this[propertyName] = _this.target[propertyName];
            });
            _this.target.on("Dispose" /* UserControlEvents.Dispose */, function () {
                _this.dispose();
            });
            return _this;
        }
        Object.defineProperty(ControlUIBase.prototype, "id", {
            set: function (value) {
                if (value === undefined || value === null || value === '') {
                    this.container.removeAttr('id');
                }
                else {
                    this.container.attr('id', value);
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ControlUIBase.prototype, "enabled", {
            set: function (value) {
                if (value) {
                    this.container.removeClass("FUI-disable" /* GeneralCssNames.Disable */);
                    this.container.removeAttr("disabled");
                    this.focusable = this.target.focusable;
                }
                else {
                    this.container.addClass("FUI-disable" /* GeneralCssNames.Disable */);
                    this.container.attr("disabled", "disabled");
                    this.focusable = false;
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ControlUIBase.prototype, "visibility", {
            set: function (value) {
                if (value) {
                    this.container.show();
                }
                else {
                    this.container.hide();
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ControlUIBase.prototype, "focusable", {
            set: function (value) {
                if (value && this.target.enabled) {
                    this.container.attr("tabindex", "0");
                }
                else {
                    this.container.removeAttr("tabindex");
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ControlUIBase.prototype, "isFocus", {
            set: function (value) {
                if (value && this.target.focusable) {
                    this.container[0].focus();
                }
                else {
                    this.container[0].blur();
                }
            },
            enumerable: false,
            configurable: true
        });
        // override
        ControlUIBase.prototype.refresh = function () {
            _super.prototype.refresh.call(this);
            this.initializeProperties();
            return this;
        };
        // override 
        ControlUIBase.prototype.createContainerEvents = function () {
            this.bindFocusAndBlurEvent();
        };
        ControlUIBase.prototype.initializeProperties = function () {
            var _this = this;
            this.target.registedProperties.forEach(function (propertyName) {
                _this[propertyName] = _this.target[propertyName];
            });
        };
        ControlUIBase.prototype.bindFocusAndBlurEvent = function (container) {
            var _this = this;
            if (container === void 0) { container = this.container; }
            container.on("focus", function () {
                _this.target.focus();
            });
            container.on("blur", function () {
                _this.target.blur();
            });
        };
        return ControlUIBase;
    }(JQueryUIBase));
    TabManager.ControlUIBase = ControlUIBase;
})(TabManager || (TabManager = {}));
