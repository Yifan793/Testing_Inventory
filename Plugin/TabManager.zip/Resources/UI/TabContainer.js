var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var TabManager;
(function (TabManager) {
    // 会影响到全局
    var TabContainerInstance = "TabContainerInstance";
    var TabMessageFlag = "TabMessageFlag";
    var TabUidGenerator = /** @class */ (function () {
        function TabUidGenerator() {
        }
        TabUidGenerator.next = function () {
            return Math.floor(Math.random() * 1000000000);
        };
        return TabUidGenerator;
    }());
    TabManager.TabUidGenerator = TabUidGenerator;
    var Utils = /** @class */ (function () {
        function Utils() {
        }
        Utils.isEmpty = function (value) {
            if (value === undefined || value === null || value === '') {
                return true;
            }
            return false;
        };
        Utils.isNotEmpty = function (value) {
            return !Utils.isEmpty(value);
        };
        Utils.isEmptyData = function (data) {
            if (Utils.isEmpty(data)) {
                return true;
            }
            var sources = Object.keys(data);
            if (sources.length === 0) {
                return true;
            }
            return sources.every(function (s) { return Utils.isEmpty(data[s]); });
        };
        return Utils;
    }());
    var Tab = /** @class */ (function () {
        function Tab(isSelectPage, pageName, url, urlTitle, usedMode, data) {
            this.originalTitle = Utils.isEmpty(urlTitle) ? "" : urlTitle.toString().trim();
            this.isSelectPage = isSelectPage;
            this.pageName = Tab.getPageName(pageName);
            this.uid = TabUidGenerator.next();
            this.url = isSelectPage
                ? Tab.getUrlFromPage(this.pageName, data)
                : (Utils.isEmpty(url) ? "" : url.toString());
            this.openMode = usedMode;
            this.data = data ? data : null;
            this.displayedTitle = this.initTitle;
            this.canBeClosed = true;
        }
        Tab.prototype.setAlwaysOpen = function () {
            this.canBeClosed = false;
        };
        Object.defineProperty(Tab.prototype, "isValid", {
            get: function () {
                if (this.isSelectPage && Utils.isNotEmpty(this.pageName)) {
                    return true;
                }
                if (!this.isSelectPage && Utils.isNotEmpty(this.url)) {
                    return true;
                }
                return false;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Tab.prototype, "isValidUrl", {
            /**
             * 简单判断合法的URL 只要以http://或者https://开头即可
             */
            get: function () {
                var lowerUrl = this.url.toLowerCase();
                return lowerUrl.indexOf("http://") === 0 || lowerUrl.indexOf("https://") === 0;
            },
            enumerable: false,
            configurable: true
        });
        Tab.getPageName = function (pageName) {
            if (Utils.isEmpty(pageName)) {
                return "";
            }
            // 确保不是number的pageName
            return pageName.toString().trim();
        };
        Object.defineProperty(Tab.prototype, "initTitle", {
            get: function () {
                if (!Utils.isEmpty(this.originalTitle)) {
                    return this.originalTitle;
                }
                if (this.isSelectPage) {
                    if (Utils.isEmpty(this.pageName)) {
                        return "...";
                    }
                    else {
                        return Forguncy.Plugin.LocalizationResourceHelper.getApplicationResource(this.getPageTitle(this.pageName));
                    }
                }
                else {
                    // 如果是url 则需要后期再次尝试截取 不过由于浏览器同源策略 可能还是获取不到
                    return this.urlDisplayedTitle;
                }
            },
            enumerable: false,
            configurable: true
        });
        Tab.prototype.getPageTitle = function (pageName) {
            // 如果没有title page就直接使用page name
            var pageTitle = pageName;
            Forguncy.Common.forguncyPostSync("Home/GetPageTitle", { PageName: this.pageName }, function (title) {
                if (!Utils.isEmpty(title)) {
                    pageTitle = title;
                }
            });
            return pageTitle;
        };
        Object.defineProperty(Tab.prototype, "urlDisplayedTitle", {
            get: function () {
                var defaultTitle = "...";
                if (Utils.isEmpty(this.url)) {
                    return defaultTitle;
                }
                try {
                    var urlObject = new URL(this.url);
                    return urlObject.hostname;
                }
                catch (e) {
                    var url = this.url;
                    if (url.indexOf("http://") === 0) {
                        url = url.substr(7);
                    }
                    else if (url.indexOf("https://") === 0) {
                        url = url.substr(8);
                    }
                    var slashIndex = url.indexOf("/");
                    var queryIndex = url.indexOf("?");
                    var domainLength = Math.min(slashIndex, queryIndex);
                    if (domainLength === -1) {
                        return url;
                    }
                    return url.substr(0, domainLength);
                }
            },
            enumerable: false,
            configurable: true
        });
        Tab.getUrlFromPage = function (page, data) {
            if (Utils.isEmpty(page)) {
                return "";
            }
            if (page.indexOf("http://") === 0 || page.indexOf("https://") === 0) {
                return page;
            }
            var url = window.location.origin + Forguncy.Helper.SpecialPath.getBaseUrl() + page;
            if (data) {
                url += "?fgc_passvalue=".concat(encodeURIComponent(JSON.stringify(data)));
            }
            return url;
        };
        Tab.equalData = function (data1, data2) {
            // 由于TabData里没有方法 所以使用JSON字符串做简单比较
            if (Utils.isEmptyData(data1) && Utils.isEmptyData(data2)) {
                return true;
            }
            try {
                return JSON.stringify(data1) === JSON.stringify(data2);
            }
            catch (_a) {
                return false;
            }
        };
        Tab.exists = function (tab1, tab2, willCompareData) {
            if (willCompareData === void 0) { willCompareData = false; }
            if (tab1.isSelectPage !== tab2.isSelectPage) {
                return false;
            }
            if (!this.isTitleEquals(tab1.originalTitle, tab2.originalTitle)) {
                return false;
            }
            if (tab1.isSelectPage) {
                // page name tab
                if (tab1.pageName === tab2.pageName) {
                    if (willCompareData) {
                        return Tab.equalData(tab1.data, tab2.data);
                    }
                    return true;
                }
            }
            else {
                // url tab
                if (tab1.url === tab2.url) {
                    return true;
                }
            }
            return false;
        };
        Tab.isTitleEquals = function (title1, title2) {
            return (Utils.isEmpty(title1) && Utils.isEmpty(title2)) ||
                title1 === title2;
        };
        return Tab;
    }());
    TabManager.Tab = Tab;
    var TabContainer = /** @class */ (function (_super) {
        __extends(TabContainer, _super);
        function TabContainer(defaultPageInfo, tabStyle, pageID) {
            var _this = _super.call(this) || this;
            _this.defaultUI = TabManagerUI;
            _this.tabList = [];
            _this.registProperty("activeTab");
            _this.tabStyle = tabStyle;
            _this.cellType = defaultPageInfo;
            TabContainer.cacheTabContainerInstance(_this, pageID);
            TabContainer.addPostMessageEventListener(pageID);
            var DefaultPageOrURL = defaultPageInfo.DefaultPageOrURL, IsDefaultPageAlwaysOpen = defaultPageInfo.IsDefaultPageAlwaysOpen, IsURL = defaultPageInfo.IsURL;
            if (DefaultPageOrURL) {
                var newTab = IsURL
                    ? new Tab(false, '', DefaultPageOrURL, '', 0 /* OpenTabMode.AlwaysOpenNewTab */)
                    : new Tab(true, DefaultPageOrURL, '', '', 0 /* OpenTabMode.AlwaysOpenNewTab */);
                if (IsDefaultPageAlwaysOpen) {
                    newTab.setAlwaysOpen();
                }
                _this.addNewTab(newTab);
            }
            return _this;
        }
        TabContainer.addTab = function (tab, pageID) {
            if (!tab.isValid) {
                return;
            }
            if (!tab.isSelectPage && tab.isValidUrl === false) {
                alert(TabManager.ResourceHelper.getResourceString("alert_message_invalid_URL"));
                return;
            }
            var currentInstance = TabContainer.getCurrentInstance(window, pageID);
            if (!currentInstance) {
                return;
            }
            currentInstance.addOrReuseTab(tab);
        };
        /**
         * 一个页面上，限制只有一个TabPlugin
         * 如果在当前也找不到TabPlugin，就一直向上层browsing context寻找，直到找到window.top上
         * 如果一直没找到 就返回null
         *
         * 如果一个browsing context有多个TabPlugin: 会使用最后添加的那个实例
         */
        TabContainer.getCurrentInstance = function (currentWindow, pageID) {
            var tabPluginInstance = currentWindow[TabContainerInstance];
            if (tabPluginInstance && tabPluginInstance[pageID]) {
                return tabPluginInstance[pageID];
            }
            var hasParent = currentWindow !== window.top;
            try {
                if (hasParent && currentWindow.parent.location.origin === location.origin) {
                    var parentPageInfo = (currentWindow.parent.Forguncy.ForguncyData.pageInfo);
                    return TabContainer.getCurrentInstance(currentWindow.parent, parentPageInfo.pageID);
                }
                else if (tabPluginInstance) {
                    /* fix FORGUNCY-4983 [FromCN]can't open tab in tabMagager if execute command on popup page
                     * 一些中国客户希望能在popup里打开父页面的tabmanager，因此如果上述方法还是没找到，就随便返回一个
                     */
                    for (var pageID_1 in tabPluginInstance) {
                        if (tabPluginInstance[pageID_1] instanceof TabManager.TabContainer) {
                            return tabPluginInstance[pageID_1];
                        }
                    }
                }
            }
            catch (error) {
                // do nothing
            }
            return null;
        };
        TabContainer.cacheTabContainerInstance = function (tabContainer, pageID) {
            var currentWindow = window;
            if (!currentWindow[TabContainerInstance]) {
                currentWindow[TabContainerInstance] = {};
            }
            currentWindow[TabContainerInstance][pageID + ""] = tabContainer;
        };
        TabContainer.clearTabContainerInstanceCache = function (pageID) {
            var currentWindow = window;
            if (currentWindow[TabContainerInstance]) {
                currentWindow[TabContainerInstance][pageID + ""] = undefined;
            }
        };
        TabContainer.addPostMessageEventListener = function (pageID) {
            if (window[TabMessageFlag]) {
                return;
            }
            window.addEventListener("message", function (ev) {
                var data = ev.data;
                if (data.type === "TITLE CHANGED" /* MessageType.TitleChange */) {
                    if (data.message && data.message.title && data.message.uid) {
                        TabContainer.refreshTitle(data.message.uid, data.message.title, pageID);
                    }
                }
                if (data.type === "CLOSE ACTIVE TAB" /* MessageType.CloseActiveTab */) {
                    var currentInstance = TabContainer.getCurrentInstance(window, pageID);
                    if (!currentInstance) {
                        return;
                    }
                    currentInstance.closeTab(currentInstance.activeTab);
                }
            });
            window[TabMessageFlag] = true;
        };
        TabContainer.refreshTitle = function (uid, title, pageID) {
            var currentInstance = TabContainer.getCurrentInstance(window, pageID);
            if (!currentInstance) {
                return;
            }
            currentInstance.refreshTabTitle(uid, title);
        };
        TabContainer.findExistedTab = function (tabList, targetTab, willCompareData) {
            if (willCompareData === void 0) { willCompareData = false; }
            if (!tabList || tabList.length === 0) {
                return;
            }
            for (var i = 0; i < tabList.length; i++) {
                var currentTab = tabList[i];
                if (Tab.exists(currentTab, targetTab, willCompareData)) {
                    return currentTab;
                }
            }
            return null;
        };
        TabContainer.prototype.goPrevious = function () {
            var currentIndex = this.tabList.indexOf(this.activeTab);
            if (0 < currentIndex) {
                this.active(this.tabList[currentIndex - 1]);
                return true;
            }
            return false;
        };
        TabContainer.prototype.goNext = function () {
            var currentIndex = this.tabList.indexOf(this.activeTab);
            if (0 <= currentIndex && currentIndex < this.tabList.length - 1) {
                this.active(this.tabList[currentIndex + 1]);
                return true;
            }
            return false;
        };
        TabContainer.prototype.active = function (tab) {
            this.activeTab = tab;
        };
        TabContainer.prototype.addOrReuseTab = function (tab) {
            if (this.cellType.HideTab) {
                tab.openMode = 3 /* OpenTabMode.ReplaceFirstTab */;
            }
            switch (tab.openMode) {
                case 0 /* OpenTabMode.AlwaysOpenNewTab */:
                    this.addNewTab(tab);
                    break;
                case 1 /* OpenTabMode.OpenExistedTabAlwaysReload */: {
                    var existedTab = TabContainer.findExistedTab(this.tabList, tab);
                    if (existedTab) {
                        existedTab.data = tab.data; // 总是使用新data
                        existedTab.url = tab.url;
                        this.reuseTab(existedTab, true);
                    }
                    else {
                        this.addNewTab(tab);
                    }
                    break;
                }
                case 2 /* OpenTabMode.OpenExistedTabOnlyReloadWhenPassedDataChange */: {
                    var existedTab = TabContainer.findExistedTab(this.tabList, tab);
                    if (existedTab) {
                        var willReload = !Tab.equalData(existedTab.data, tab.data);
                        existedTab.data = tab.data; // 总是使用新data
                        existedTab.url = tab.url;
                        this.reuseTab(existedTab, willReload);
                    }
                    else {
                        this.addNewTab(tab);
                    }
                    break;
                }
                case 3 /* OpenTabMode.ReplaceFirstTab */: {
                    var existedTab = this.tabList.length > 0 ? this.tabList[0] : null;
                    if (existedTab) {
                        existedTab.data = tab.data; // 总是使用新data
                        existedTab.url = tab.url;
                        this.reuseTab(existedTab, true);
                    }
                    else {
                        this.addNewTab(tab);
                    }
                    break;
                }
            }
        };
        TabContainer.prototype.closeTab = function (tab) {
            var cancel = this.checkPageDirty(tab);
            if (cancel) {
                return;
            }
            var isActiveTab = this.activeTab ? (tab.uid === this.activeTab.uid) : false;
            if (isActiveTab) {
                if (this.goNext() === false) {
                    this.goPrevious();
                }
            }
            var index = this.tabList.indexOf(tab);
            if (index >= 0) {
                this.tabList.splice(index, 1);
            }
            this.dispatch("TabsChange" /* TabManagerEvents.TabsChanged */);
            this.dispatch("TabsClosed" /* TabManagerEvents.TabsClosed */, [tab]);
        };
        TabContainer.prototype.checkPageDirty = function (tab) {
            try {
                var iframe = tab.iframeContainer[0];
                var pageDirtyCheckManager = iframe.contentWindow.Forguncy.ForguncyData.pageDirtyCheckManager;
                var dirtyInfo = pageDirtyCheckManager.getDirtyElement(true);
                if (dirtyInfo) {
                    var leave = confirm(Forguncy.RS.LeaveSiteConfirm);
                    Forguncy.ForguncyData.pageDirtyCheckManager.consoleWithNewLog(dirtyInfo, "Close Tab: " + tab.displayedTitle, leave);
                    if (!leave) {
                        return true;
                    }
                }
            }
            catch (_a) {
                // 避免跨域引起的error崩溃
            }
            return false;
        };
        TabContainer.prototype.refreshTabTitle = function (uid, title) {
            if (Utils.isEmpty(title)) {
                return;
            }
            var tab = this.findTabByUid(uid);
            var canChangeTitle = tab && Utils.isEmpty(tab.originalTitle) && tab.isSelectPage;
            if (canChangeTitle) {
                tab.displayedTitle = title;
                this.dispatch("TabsChange" /* TabManagerEvents.TabsChanged */);
            }
        };
        TabContainer.prototype.findTabByUid = function (uid) {
            if (this.tabList && this.tabList.length > 0) {
                var uidNumber_1 = parseInt(uid);
                var tab = this.tabList.filter(function (t) { return t.uid === uidNumber_1; });
                if (tab.length === 0) {
                    return null;
                }
                return tab[0];
            }
            return null;
        };
        TabContainer.prototype.reuseTab = function (tab, willReload) {
            if (willReload === void 0) { willReload = false; }
            this.active(tab);
            if (willReload) {
                this.dispatch("ReloadTab" /* TabManagerEvents.ReloadTab */, [tab]);
            }
        };
        TabContainer.prototype.addNewTab = function (tab) {
            this.tabList.push(tab);
            this.dispatch("TabsChange" /* TabManagerEvents.TabsChanged */);
            this.active(tab);
        };
        return TabContainer;
    }(TabManager.UserControl));
    TabManager.TabContainer = TabContainer;
    var TabManagerUI = /** @class */ (function (_super) {
        __extends(TabManagerUI, _super);
        function TabManagerUI() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        // override
        TabManagerUI.prototype.createContainer = function () {
            this.container = $("<div class=\"".concat("FTM-container" /* TabContainerClassNames.Container */, "\"></div>"));
            this.bindIframeActive();
        };
        TabManagerUI.prototype.bindIframeActive = function () {
            window.addEventListener('blur', function (e) {
                if (document.activeElement.className === "FTM-content-iframe" /* TabContentClassNames.IFrame */) {
                    $("." + "FTM-nav-menu-wrap" /* TabHeadClassNames.NavMenuWrap */).hide();
                }
            });
        };
        TabManagerUI.prototype.createContainerEvents = function () {
            var _this = this;
            _super.prototype.createContainerEvents.call(this);
            this.toggleContainer();
            this.target.on("TabsChange" /* TabManagerEvents.TabsChanged */, function () {
                _this.toggleContainer();
            });
            this.target.on("TabsClosedAllOrOther" /* TabManagerEvents.TabsClosedAllOrOther */, function () {
                _this.toggleContainer();
            });
        };
        // override
        TabManagerUI.prototype.createChildren = function () {
            var header = this.target.createUI(TabManager.TabHeadUI);
            var content = this.target.createUI(TabManager.TabContentUI);
            if (this.target.cellType.HideTab) {
                header.container.css("display", "none");
                content.container.css("height", "100%");
            }
            else {
                content.container.css("height", "calc(100% - 32px)");
            }
            this.addChild(header);
            this.addChild(content);
        };
        /**
         * 在没有任何tab的时候 不显示container
         * related to Bug 29759
         */
        TabManagerUI.prototype.toggleContainer = function () {
            var opacity = (this.target.tabList && this.target.tabList.length > 0) ? 1 : 0;
            this.container.css('opacity', opacity);
        };
        return TabManagerUI;
    }(TabManager.ControlUIBase));
    TabManager.TabManagerUI = TabManagerUI;
})(TabManager || (TabManager = {}));
